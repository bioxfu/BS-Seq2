//  BRAT is a whole genome bisulfite sequence mapping program
//  Copyright (C) 2009  Elena Yavorska Harris
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
// 
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.


#include<iomanip>
#include<map>
#include<bitset>
#include<ctime>
#include<list>
#include<cmath>
#include<vector>
#include<string.h>
#include<iostream>
#include<fstream>
#include<sstream>
#include<algorithm>
#include<assert.h>
#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>

using namespace std;

typedef unsigned long int _uli;
typedef unsigned int _ui;
typedef unsigned short int _usi;

//lookup8.c, by Bob Jenkins, January 4 1997, Public Domain.
#define mix64(a,b) \
{ \
  a -= b;  a ^= (b>>43); \
  b -= a; b ^= (a<<9); \
  a -= b; a ^= (b>>38); \
  b -= a; b ^= (a<<23); \
  a -= b; a ^= (b>>35); \
  b -= a; b ^= (a<<49); \
  a -= b; a ^= (b>>12); \
  b -= a; b ^= (a<<18); \
}

/*
#define mix64(a,b,c) \
{ \
  a -= b; a -= c; a ^= (c>>43); \
  b -= c; b -= a; b ^= (a<<9); \
  c -= a; c -= b; c ^= (b>>8); \
  a -= b; a -= c; a ^= (c>>38); \
  b -= c; b -= a; b ^= (a<<23); \
  c -= a; c -= b; c ^= (b>>5); \
  a -= b; a -= c; a ^= (c>>35); \
  b -= c; b -= a; b ^= (a<<49); \
  c -= a; c -= b; c ^= (b>>11); \
  a -= b; a -= c; a ^= (c>>12); \
  b -= c; b -= a; b ^= (a<<18); \
  c -= a; c -= b; c ^= (b>>22); \
}
*/
//End lookup8.c, by Bob Jenkins, January 4 1997, Public Domain.


class Stat{
public:


	long int mapped_pairs;
	long int ambiguous;
	long int unmapped;
	long int single_mapped;
	long int single_ambiguous;
	long int broken_dif_chroms;
	long int broken_wrong_insert;
	long int broken_inverse;
	long int broken_mate_unmapped;
	long int broken_mate_amb; //if pair is unmapped and mate is ambiguous, means something else is wrong
	//dif chroms, inverse or wrong insert, otherwise it would be counted as amb pair
	long int broken_both_unmapped;
	long int invalid;
	long int mapped_first_Arich;
	Stat();
};
Stat::Stat(){

	mapped_pairs = 0; 
	ambiguous = 0; 
	unmapped = 0; 
	single_mapped = 0;
	single_ambiguous = 0;
	 broken_dif_chroms = 0;
	 broken_wrong_insert = 0;
	 broken_inverse = 0;
	 broken_mate_unmapped = 0;
	 broken_mate_amb = 0; //if pair is unmapped and mate is ambiguous, means something else is wrong
	//dif chroms, inverse or wrong insert, otherwise it would be counted as amb pair
	 broken_both_unmapped = 0;
	invalid = 0;
	mapped_first_Arich = 0;
}
unsigned int MAX_MISM = 1000000;

class Mates{
public:
	Mates(unsigned int x, unsigned int y, unsigned int z, char st, short int mark, bool present_cg) : chrom_id(x), pos1(y), pos2(z), strand(st), mark_unique(mark), mism1(MAX_MISM), mism2(MAX_MISM), min_mism(MAX_MISM), is_cg(present_cg), A_rich(false) {}; 
	Mates(): chrom_id(-1), pos1(0), pos2(0), strand('+'), mark_unique(0), mism1(MAX_MISM), mism2(MAX_MISM), min_mism(MAX_MISM), is_cg(false), A_rich(false) {};
	void operator =(Mates a){ chrom_id = a.chrom_id; pos1 = a.pos1 ; pos2 = a.pos2; strand = a.strand; mark_unique = a.mark_unique; };
	unsigned int chrom_id;
	unsigned int pos1;
	unsigned int pos2;
	char strand;
	short int mark_unique;
	unsigned int mism1;
	unsigned int mism2;
	unsigned int min_mism;
	bool is_cg;
	bool A_rich;
};

long int Reverse(unsigned long int i, int bits){//by Nicholas Allen

i = ((i >> 1) & 0x5555555555555555) | ((i & 0x5555555555555555) << 1);
i = ((i >> 2) & 0x3333333333333333) | ((i & 0x3333333333333333) << 2);
i = ((i >> 4) & 0x0F0F0F0F0F0F0F0F) | ((i & 0x0F0F0F0F0F0F0F0F) << 4);
i = ((i >> 8) & 0x00FF00FF00FF00FF) | ((i & 0x00FF00FF00FF00FF) << 8);
i = ((i >> 16) & 0x0000FFFF0000FFFF) | ((i & 0x0000FFFF0000FFFF) << 16);
i = ( i >> 32 ) | ( i << 32);
i = i >> (64 - bits);

return i;
}
void convert_lmer_ta_long(string lmer, vector<unsigned long int> &ta_read, int asize){
	long int j, i;
	j = 0;
	while( j < asize){
		unsigned long int gb = 0; 
		for(i = 0; i < 64 && j < asize; i++){
			gb <<= 1;
			if(lmer[j] == 'T' || lmer[j] == 't' ||  lmer[j] == 'C' || lmer[j] == 'c')
				gb |= 1;
			j++;
		}//for i
		
		ta_read.push_back(gb);

	}//while j
}//convert_ta

void convert_lmer_c_long(string current_chrom, vector<unsigned long int> &cg_read,
						 int num_iter)
{//this function is used only once when there is a beginning of a chromosome
	//aread is an lmer in a genome
	//gb is binary representative of this genome lmer
	long int j =0, i = 0;

	while(i < num_iter){
		unsigned long int gb = 0;

		for(j = 0; j < 64 && i < num_iter; j++){
			gb <<= 1;
			if(current_chrom[i] == 'C' || current_chrom[i] == 'c' ){
				gb |= 1;
			}
			else if(current_chrom[i] == 'G' || current_chrom[i] == 'g'){
				gb |= 1;
			}
			i++;
		}//for j
		cg_read.push_back(gb);
	}//while

}//connvert_lmer_c()

void convert_lmer_c(string current_chrom, unsigned long int &gb, int num_iter)
{//this function is used only once when there is a beginning of a chromosome
	//aread is an lmer in a genome
	//gb is binary representative of this genome lmer
	long int j ;

	gb = 0;
		for(j = 0; j < num_iter; j++){
			gb <<= 1;
			if(current_chrom[j] == 'C' || current_chrom[j] == 'c' ){
				gb |= 1;
			}
			else if(current_chrom[j] == 'G' || current_chrom[j] == 'g'){
				gb |= 1;
			}

		}//for j

}//connvert_lmer_c()



void convert_lmer_ta(string lmer, unsigned long int &gb, unsigned long int &ns, int asize){
	long int j;
	gb = 0; 
	ns = 0;
	for(j = 0; j < asize; j++){
		gb <<= 1;
		ns <<= 1;

		if(lmer[j] == 'T' || lmer[j] == 't' ||  lmer[j] == 'C' || lmer[j] == 'c')
			gb |= 1;
		else if(lmer[j] == 'N' || lmer[j] == 'n')
			ns |= 1;

	}//for j
}//convert_ta

void next_lmer_ta(char ch, unsigned long int &gb, unsigned long int &ns, unsigned long int MASK_READ){

	gb <<= 1;
	ns <<= 1;

	if(ch == 'T' || ch == 't'  || ch == 'C' || ch == 'c')
		gb |= 1;
	else if(ch == 'N' || ch == 'n')
		ns |= 1;

	gb &= MASK_READ;
	ns &= MASK_READ;

}//next_lmer_ta()


long int str_to_int(string s)
{
	istringstream is(s);
	long int result = -1;
	is >> result;
	return result;
}

string int_to_str(long int x)
{
	stringstream outstr;
	outstr << x;
	return outstr.str();

}
string double_to_str(double x)
{
	stringstream outstr;
	outstr << x;
	return outstr.str();

}

long int max(long int x, long int y)
{	
	if(x > y)
		return x;
	else
		return y;

}
unsigned long int min(unsigned long int x, unsigned long int y){ 
	if(x < y)
		return x;
	else
		return y;
}




void next_lmer_cg(char ch, unsigned long int &gb,  unsigned long int MASK_READ){

	gb <<= 1;

	if(ch == 'G' || ch == 'g'  || ch == 'C' || ch == 'c')
		gb |= 1;

	gb &= MASK_READ;

}//next_lmer_ta()
void next_lmer(char ch, unsigned long int &gb, unsigned long int &ns, 
			   unsigned long int &cg, unsigned long int MASK_READ)
{
	gb <<= 1;
	ns <<= 1;
	cg <<=1;

	if(ch == 'T' || ch == 't')  
		gb |= 1;
	else if(ch == 'G' || ch == 'g'){
		cg |= 1;
	}
	else if(ch == 'C' || ch == 'c'){
		gb |= 1;
		cg |= 1;
	}
	else if(ch == 'N' || ch == 'n')
		ns |= 1;

	gb &= MASK_READ;
	cg &= MASK_READ;

	ns &= MASK_READ;

}//next_lmer()

void usage(){

	string mes("\nUSAGE: brat_bw -P <directory-bw-index> -s <input-reads> -o <output> [OPTIONS]\n\nOptions:\n");
	string gen_ref_opt("  -P <directory-bw-index>    directory with BWT index");
	string four_strands(" -W                         sets mapping to four PCR-product strands (default: mapping to two original strands)");
	string singles(    "  -s <input-reads-file>      file with single reads (or queries)");
	string output(     "  -o <output-file>");
	string is_pair(    "  -pe                        set Pair-End mapping (if not specified,\n                          mapping for single reads is done)");
	string is_bs(      "  -bs                        set BS-mapping (if not specified,\n                          normal mapping is done)");
	string first(      "  -1 <paired-ends-file1>     mates 1");
	string second(     "  -2 <paired-ends-file2>     mates 2");
	string min_insert( "  -i <min>                   min insert");
	string max_insert( "  -a <max>                   max insert");
	string arich(      "  -A                         singles that are pair2 file,\n                          that are mapped to an A-rich strand");
	string out_amb(    "  -M                         output ambiguous reads/pairs");
	string allow_C_to_T ("  -C                       allow C to T matches (default: don't allow C in a read to map to T in a genome, count this as a mism)");
	string mism(	   "  -m <non-negative integer>  the number of non-BS-mismatches allowed");
//	string first_bits( "  -f <integer 32..64>        the first <int> bases, within which only one non-BS-mismatch is allowed (default: min(read_len, 48))");
	string mism_first( "  -F <integer 0 or 1>        the number of non-BS-mismatches in the first bits (first bits are defined with -f), default: 0");
//	string multiple_shifts("   -k <int 1 or 2>		 improves accuracy when set to 2, default: 2");
	string shift_delta("  -D <integer>			     interval width, by which multi-seed is shifted (default 16 bases)");
	string total_shifts("  -K <integer>              maximum number of multi-seeds considered (default: 10)");//it is read_len - BIG_seed divided by shift_delta
	cout << mes << endl;
	cout << gen_ref_opt << endl << four_strands << endl << singles << endl
        	<< output << endl
		<< is_pair << endl << is_bs << endl
		<< first << endl << second << endl << min_insert << endl << max_insert
		<< endl << arich << endl <<  out_amb << endl 
		<< mism << endl <<  mism_first << endl  << allow_C_to_T  
		<< shift_delta << endl << total_shifts << endl;

	string mes2(      "Limitations:\n");
	string ref_size(  "  a single reference size <= 2^45");
	string chrom_ids( "  number of references <= 2^18");
	string space(     "  space <= (total references sizes)*4.5*8 + 16*(2^24)");
	
	cout << mes2 << endl;
	cout << ref_size << endl << chrom_ids << endl << space << endl;

	string mes3(      "Output Format:\n");
	string ri(        "  read id <int>           the order of a read/pair in the input file (starts\n                          with 0)");
	string r1(        "  read1 <string>          mate 1 as in the input file");
	string r2(        "  read2 <string>          (pair-end only) mate 2 as in the input file");
	string chr(       "  reference name <string>");
	string str(       "  strand                  (+) if mate 1 is found in forward strand,\n                          (-) if mate 1 is in reverse strand");
	string pos1(      "  position1 <int>         mate 1 leftmost position in the reference");
	string pos2(      "  position2 <int>         (pair-end only) mate 2 leftmost pos. in the reference");
	string mism1(     "  mism1 <int>             number of mismatches in mate 1, 5' mate");
	string mism2(     "  mism2 <int>             (pair-end only) number of mismatches in mate 2, 3' mate");	
	cout << endl << mes3 << endl;
	cout << ri << endl << r1 << endl << r2 << endl << chr << endl << str << endl
		<< pos1 << endl << pos2 << endl << mism1 << endl << mism2 << endl;
}//usage()


struct gen_info
{
	gen_info() : pos(0), chrom(0) {}
	~gen_info(){}
	gen_info(unsigned int p, unsigned short int c) : pos(p), chrom(c) {}
	void operator =(gen_info a){ chrom = a.chrom; pos = a.pos; };

	unsigned int pos ;
	unsigned short int chrom ;
};

class Anchor{
public:
	Anchor(int argc, char* argv[], _usi Genome_ct_ga_flag);//1 for CT, 2 for GA
	~Anchor();

	vector<string> references_files;
	vector<unsigned long int> chrom_blocks;
	vector<unsigned long int> size_chrom;
	vector<unsigned long int> starts_size_chrom;
	map<long int, string> chroms_names;

	vector< vector<_ui> > num_occ_sqr;
	vector< unsigned short int* > num_occ;//indexed by char
	vector< _usi > num_occ_bytes;//hash table for the number of 1s in a byte

	unsigned long int *seeds;

	unsigned int *pos_indices;
	unsigned int *pos_num_sqr;//to hold # of pos occ in square blocks 64x64 [0...up to cur]
	unsigned short int *pos_num_occ;
	unsigned int pos_indices_total;

	vector< _ui > C;//to store total number of occ of As and Ts in ta-genome
	vector<_uli> mask;
	vector< _uli > mask_opp;//
	vector<_uli> mask_opp_zero;

	_uli binary_total;//size of binary representation of the genome
	_uli ta_size;//64-word size of genome
	_uli genome_byte_size;
	int parse_options(int argc, char* argv[]);

	void make_mask();
	void make_mask_opp();

	void input_info();//chrom info, C, pos_sizes (sizes of lists of keys for genome positions identification from given index in BWT)
	void read_num_occ_sqr();
	void read_num_occ();
	void read_pos_sqr();
	void read_pos_occ();
	_uli get_pos_lmer(_uli &cur_byte, _uli aread_len);

	void print(Stat &astat);

	long int convert_lmer_ta_cg(string lmer, _uli &ta, _uli &cg, _uli &ns, vector<_uli>  &full, vector<_uli>  &full_rc, _ui asize, Mates &mates_pairs);
	long int convert_lmer_ta_cg(string lmer, vector<_uli> &ta_read, vector<_uli> &cg_read, vector<_uli> &ns_read,
		vector<_uli> &full, vector<_uli> &full_rc, _ui read_len, Mates &mates_pairs);
	void revcompl_lmer_ta_cg(const vector<_uli> &ta_read, const vector<_uli> &cg_read, const vector<_uli> &ns_read, 
		const _ui &read_len, vector<_uli> &ta_rc_read, vector<_uli> &cg_rc_read, vector<_uli> &ns_rc_read);
	void shift_back(vector<_uli> &ta_read, int asize, const _ui &read_len);
	void convert_gen_mer_ta(unsigned long int &ta_gen_lmer,
					 unsigned long int gen_pos,
					 unsigned long int aread_len, const Anchor &anc);
	void convert_gen_mer_cg(unsigned long int &ta_gen_lmer,
					 unsigned long int gen_pos,
					 unsigned long int aread_len, const Anchor &anc);
	void convert_gen_mer_ns(unsigned long int &ta_gen_lmer,
					 unsigned long int gen_pos,
					 unsigned long int aread_len);

	void convert_gen_mer_ta(vector<_uli> &ta_gen_lmer,
					 unsigned long int gen_pos,
					 unsigned long int aread_len, const Anchor &anc);
	void convert_gen_mer_cg(vector<_uli> &ta_gen_lmer,
					 unsigned long int gen_pos,
					 unsigned long int aread_len, const Anchor &anc);
	void convert_gen_mer_ns(vector<_uli> &ta_gen_lmer,
					 unsigned long int gen_pos,
					 unsigned long int aread_len);

	int count_mism(unsigned long int bm);
	int count_mism_long(unsigned long int bm);


	void print_singles(ofstream &out, bool second_mates, const _uli &read_id, 
				const string & aread1, const _uli &st1, const _uli &en1,  Mates &mates_pairs, Stat &astat, const _uli &read_len);

	void update_singles(Mates &mates_pairs, const char &strand,	const _ui &pos1, 
				const _usi &mism1, bool &pair_ambiguous, bool map_mism);

	void count_ag_mism(const _uli &ta_read1, const _uli &c_read1, const _uli &cg_gen_mer1,
				_uli &ag_mism1);
	void count_tc_mism(const _uli &ta_read1, const _uli &c_read1, const _uli &cg_gen_mer1,
				_uli &ag_mism1);
	int cg_match(const _uli &read_len1, const _uli &pos1, const _uli &ta_read1, const _uli &c_read1,
				_uli &ta_check, const bool &forward, bool &cg_mism1, const _uli &ns_read1, const Anchor &anc);
	void ta_match(const _uli &read_len1, const _uli &pos1, const _uli &ta_read1, _uli &ta_check, const _uli &ns_read1, 
		int &mism1, const Anchor &anc);


	void count_ag_mism(const vector<_uli> &ta_read1, const vector<_uli> &c_read1, const vector<_uli> &cg_gen_mer1,
	vector<_uli> &ag_mism1);
	void count_tc_mism(const vector<_uli> &ta_read1, const vector<_uli> &c_read1, const vector<_uli> &cg_gen_mer1,
	vector<_uli> &ag_mism1);
	int cg_match(const _uli &read_len1, const _uli &pos1, const vector<_uli> &ta_read1, const vector<_uli> &c_read1,
	vector<_uli> &ta_check, const bool &forward, bool &cg_mism1, const vector<_uli> &ns_read1, const Anchor &anc);

	void ta_match(const _uli &read_len1, const _uli &pos1, const vector<_uli> &ta_read1, vector<_uli> &ta_check, 
		const vector<_uli> &ns_read1, int &mism1, const Anchor &anc);

	void retreive_seed(_ui ind, _uli &sp , _uli &ep);
	void align_linear(const _uli &ta, _uli &sp, _uli &ep, _uli read_len1, _uli &remainder);
	void align_linear(vector<_uli> ta, _uli &sp, _uli &ep, _uli read_len1, _uli &remainder, _uli y);//overloaded for long reads
	void fill_ta_rest(vector<_uli> &ta, vector<long int> &lengths, int &bl, _uli &remainder, _uli &ta_rest, int &asize);
	void map_pos(const _uli &sp, const _uli &ep, const _uli &ta_read, const _uli &read_len, const _uli &c_read, 
		const bool &forward, bool &pair_amb, const _uli &remainder, Mates &mates_pairs,
		const _uli &ns_read1, bool mism_map, const Anchor &anc);

	void map_pos_mism(const vector<_uli> &acgt_read, const _uli &ta_read, const _uli &read_len, const _uli &c_read, 
		const bool &forward, bool &pair_amb,  Mates &mates_pairs,
		const _uli &ns_read1, bool mism_map, const Anchor &anc);

	void map_pos_mism_long(const vector<_uli> &acgt_read, const _uli &ta_read, const _uli &read_len, const _uli &c_read, 
		const bool &forward, bool &pair_amb,  Mates &mates_pairs,
		const _uli &ns_read1, bool mism_map, const Anchor &anc);

	void map_pos_mism(const vector<_uli> &acgt_read, const vector<_uli> &ta_read, const _uli &read_len, 
		const vector<_uli> &c_read, const bool &forward, bool &pair_amb,  Mates &mates_pairs,
		const vector<_uli> &ns_read1, bool mism_map, const Anchor &anc);

	void map_pos_mism_long(const vector<_uli> &acgt_read, const vector<_uli> &ta_read, const _uli &read_len, 
		const vector<_uli> &c_read, const bool &forward, bool &pair_amb,  Mates &mates_pairs,
		const vector<_uli> &ns_read1, bool mism_map, const Anchor &anc);

	void map_pos(const _uli &sp, const _uli &ep, const vector<_uli> &ta_read1, const _uli &read_len1, const vector<_uli> &c_read1, 
		const bool &forward, bool &pair_ambiguous, const _uli &remainder, Mates &mates_pairs,
		const vector<_uli> &ns_read1, bool mism_map, const Anchor &anc);


	void align_mism(const _uli &ta_seed, const _uli &new_read_len, _uli &sp, _uli &ep, _uli &remainder, 
		const bool &forward, vector< pair< pair<_ui, _ui> , _ui > > &sp_ep_remainder);
	void align_mism_short(const _uli &ta, const _uli &read_len, _uli &sp, _uli &ep, _uli &remainder, 
		const bool &forward, vector< pair< pair<_ui, _ui>, pair<_ui, _ui> > > &sp_ep_remainder, const vector<_uli> &all_mism_ta );
	void get_all_backtrace(const _uli &ta_mism, vector<_uli> &all_mism, _uli mism_ind, bool forward, int &num_mism );
	void get_all_backtrace(const vector<_uli> ta_seed, vector< vector<_uli> > &all_mism, _uli mism_ind, bool forward, int &num_mism);

	void print_pairs(const _uli &read_id, const string &aread1, const _uli &read_len1, const _uli &st1,
		const _uli & en1,  Mates &mates_pairs1, const string &aread2, const _uli &read_len2, 
		const _uli &st2, const _uli &en2,  Mates &mates_pairs2, Stat &astat);

	_uli pos_Occ(_uli &sp);
	_uli Occ(_uli ch, _uli *sp);	
	void exact_match(_uli ta_read, _uli &sp, _uli &ep, _uli read_len, _uli &remainder, _uli &valid_sp, _uli &valid_ep);//sp=1, ep = 0, remainer = 0: init
	void exact_match_seed(_uli ta_read, _uli &sp, _uli &ep, _uli read_len, _uli &remainder);
	_uli get_bwt_lmer(_uli sp, _uli asize, _uli ch);
	_uli find_gen_pos(_uli sp, _uli remainder);
	void lf_map(_uli * &sp);
	void read_pos_index();//index of pos_index in counts not Bytes
	_uli get_marked_char(_uli *sp);
	_uli get_bwt_char(_uli *sp);
	_uli get_ns_lmer(_uli sp);
	void read_genome(ifstream &in, _uli * &agenome);
	void read_seeds();

	_uli *bwt_genome;
	_uli *ta_genome;
	_uli *cg_genome;
	_uli *ns_genome;
	_uli *bwt_marked;//1 if bwt[i] has gen index

	string prefix;
	_ui num_chroms;
	unsigned long int len_mer;
	unsigned long int read_len;
	_uli hash_table_size;
	long int min_insert;
	long int max_insert;
	unsigned long int MASK_BYTE;
	unsigned long int MASK_READ;
	unsigned long int MASK_LMER;
	unsigned long int MASK_HALF;
	unsigned long int MASK_SEED;
	unsigned long int byte_size;
	unsigned long int abyte ;
	unsigned long int SIZE ;//genome char per an unsigned long int
	unsigned long int SEED;
	unsigned long int BIG_SEED;
	unsigned long int MIN_READ;
	unsigned long int STEP;
	unsigned long int two_in_Step;
	unsigned long int two_in_Size; //log_2(SIZE)
	unsigned long int two_in_Min_Read;
	unsigned long int MASK_SIZE;
	unsigned long int block_size ;
	unsigned long int double_block ;//2 end of lines
	unsigned long int two_in_byte ;//log_2(byte_size)
	unsigned long int block_byte_prod_divide ;//=log_2(256*8)
	unsigned long int block_divide ;//log_2(256)
	unsigned long int bytes;//number of bytes per unsigned long int
	unsigned long int half_ui;
	unsigned long int two_in_half_ui;
	_uli block_64;//64*64=4096
	_uli block_32;//32*32 = 1024
	_uli block_256; //256*256
	_uli two_in_block_64;//2^12=4096
	_uli two_in_block_32;//2^10
	_uli two_in_block_256;//2^16 = 256^2
	_uli two_in_32;
	_uli min_read_len;

	int mism_thresh;
	_ui first_bits;//within these first bits only one non-BS-mism is allowed
	_ui all_shifts;//improves accuracy at expence of slower alignment

	unsigned long int MASK_chrom;
	ofstream out_pairs;
	ofstream out_mates1;

	ofstream out_amb1;
	ofstream out_amb2;
	ofstream out_unmapped1;
	ofstream out_unmapped2;

	string output_pairs;
	string reads_file1;
	string reads_file2;

	string is_pe;
	unsigned long int cur_block;



	string is_bs;
	bool cascade_amb;
	bool A_rich;
	bool unmapped;


	long int total_reads;
	unsigned long int dif_len_mer;

	bool out_amb;

	ifstream in_bwt;
	ifstream in_num_occ;
	ifstream in_num_sqr;	
	ifstream in_ta_genome;
	ifstream in_cg_genome;
	ifstream in_ns_genome;
	ifstream in_pos_indices;
	ifstream in_pos_sqr;
	ifstream in_pos_occ;
	ifstream in_chrom;
	ifstream in_marked;
	ifstream in_seeds;

	void error_input(string inp);
	_uli current_read_id;
	_uli orig_gen_inL;
	_uli orig_num_sqr;
	_uli orig_num;

	_uli debug;
	//to support 2-bit BWT
	_uli full_binary_total;
	_uli full_size;
	void read_bwt_genome();
	_usi Genome;
	vector< vector<_usi> > num_occ_char;//hash table for the number of char in 64-bit, 32-bases word
	void count_char(_uli kmer, vector<_usi> & characters, int asize);
	_uli half_SEED;

	void space_release();
	int allow_C_to_T;//when set allows Cs map to Ts for forward, and G to A to rev-compl
	_uli max_num_shifts;
	_uli shift_delta;
	_uli two_in_shift_delta;
	_uli half_word;
	void align_linear_seed(vector<_uli> ta, _uli &sp, _uli &ep, _uli read_len1, _uli &remainder, _uli total_bits);
	void init_params(long int read_len);
	int max_shift_delta;
	int two_in_max_shift_delta;

	bool four_strands;//to support 4-strands PCR-product mapping
	void read_rev_complement(string &aread, const _uli &read_len);
};	

void Anchor::init_params(long int read_len)
{
        if(read_len <= 55){
                shift_delta = 8;//in bits
                two_in_shift_delta = 2;//log_base2(4) 4 is in bases
				if(first_bits > 0)
					BIG_SEED = read_len;
        }
        else if(read_len <= 64){
                shift_delta = 16;//in bits
                two_in_shift_delta = 3;//log_base2(8) 4 is in bases
  				if(first_bits > 0 && read_len < 60)
					BIG_SEED = read_len;
				else if(first_bits > 0)
					BIG_SEED = 32;
        }
        else if(read_len <= 75){
				if(first_bits > 0)
					BIG_SEED = 32;

                shift_delta = 16;//in bits
                two_in_shift_delta = 3;//log_base2(8) 4 is in bases
        }
        else if(read_len <= 200){
			if(first_bits > 0)
                BIG_SEED = 32;
            shift_delta = 32;//in bits
            two_in_shift_delta = 4;//log_base2(16) 4 is in bases
        }
		else{
			if(first_bits > 0)
                BIG_SEED = 32;
            shift_delta = max_shift_delta;//in bits
            two_in_shift_delta = two_in_max_shift_delta;//log_base2(16) 4 is in bases		
		
		}


}//init_params


void Anchor::space_release()
{
	if(bwt_genome != 0)
		delete [] bwt_genome;
	bwt_genome = 0;

	if(ns_genome != 0)
		delete [] ns_genome;
	ns_genome = 0;
	if(ta_genome != 0)
		delete [] ta_genome;
	ta_genome = 0;
	if(cg_genome != 0)
		delete [] cg_genome;
	cg_genome = 0;
	if(bwt_marked != 0)
		delete [] bwt_marked;
	bwt_marked = 0;
	for(int y = 0; y < 4; y++){
		if(num_occ[y] != 0)
			delete [] num_occ[y];
		num_occ[y] = 0;
	}
	if(pos_indices != 0)
		delete [] pos_indices;
	pos_indices = 0;
	if(pos_num_occ != 0)
		delete [] pos_num_occ;
	pos_num_occ = 0;
	if(pos_num_sqr != 0)
		delete [] pos_num_sqr;
	pos_num_sqr = 0;
	if(seeds != 0)
		delete [] seeds;
	seeds = 0;

	in_bwt.close();
	in_num_occ.close();
	in_num_sqr.close();
	in_pos_sqr.close();
	in_pos_occ.close();
	in_ta_genome.close();
	in_cg_genome.close();
	in_ns_genome.close();
	in_pos_indices.close();
	in_chrom.close();
	in_marked.close();

	out_unmapped1.close();
	out_unmapped2.close();
}//space_release

Anchor::~Anchor(){

	if(bwt_genome != 0)
		delete [] bwt_genome;
	bwt_genome = 0;

	if(ns_genome != 0)
		delete [] ns_genome;
	ns_genome = 0;
	if(ta_genome != 0)
		delete [] ta_genome;
	ta_genome = 0;
	if(cg_genome != 0)
		delete [] cg_genome;
	cg_genome = 0;
	if(bwt_marked != 0)
		delete [] bwt_marked;
	bwt_marked = 0;
	for(int y = 0; y < 4; y++){
		if(num_occ[y] != 0)
			delete [] num_occ[y];
		num_occ[y] = 0;
	}
	if(pos_indices != 0)
		delete [] pos_indices;
	pos_indices = 0;
	if(pos_num_occ != 0)
		delete [] pos_num_occ;
	pos_num_occ = 0;
	if(pos_num_sqr != 0)
		delete [] pos_num_sqr;
	pos_num_sqr = 0;
	if(seeds != 0)
		delete [] seeds;
	seeds = 0;

	in_bwt.close();
	in_num_occ.close();
	in_num_sqr.close();
	in_pos_sqr.close();
	in_pos_occ.close();
	in_ta_genome.close();
	in_cg_genome.close();
	in_ns_genome.close();
	in_pos_indices.close();
	in_chrom.close();
	in_marked.close();

	out_unmapped1.close();
	out_unmapped2.close();
//	cout << "Anchor is finished" << endl;
}
void Anchor::error_input(string inp)
{
	cout << "Could not open " << inp << endl;
	space_release();
	exit(0);
}
int Anchor::count_mism(unsigned long int bits){

	int count_ones = num_occ_bytes[bits & mask[SEED]];
	_uli bits2 = bits >> SEED;
	_uli bits3 = bits2 >> SEED;
	count_ones += num_occ_bytes[bits2 & mask[SEED]];
	count_ones += num_occ_bytes[bits3];

        return count_ones;

}//count_mism()

int Anchor::count_mism_long(unsigned long int bits){

/////////////////Andrew Smith author of the following code:
  bits = ((bits & 0xAAAAAAAAAAAAAAAA) >> 1)  + (bits & 0x5555555555555555);
  bits = ((bits & 0xCCCCCCCCCCCCCCCC) >> 2)  + (bits & 0x3333333333333333);
  bits = ((bits & 0xF0F0F0F0F0F0F0F0) >> 4)  + (bits & 0x0F0F0F0F0F0F0F0F);
  bits = ((bits & 0xFF00FF00FF00FF00) >> 8)  + (bits & 0x00FF00FF00FF00FF);
  bits = ((bits & 0xFFFF0000FFFF0000) >> 16) + (bits & 0x0000FFFF0000FFFF);
  return ((bits & 0xFFFFFFFF00000000) >> 32) + (bits & 0x00000000FFFFFFFF);
/////////////////////END Andrew Smith

}//count_mism_long()

Anchor::Anchor(int argc, char* argv[], _usi Genome_ct_ga_flag)
{
	four_strands = false;

	max_shift_delta = 64;//in bits
	two_in_max_shift_delta = 5;

	half_word = 32;
	max_num_shifts = 10;
	shift_delta = 32;//in bits
	allow_C_to_T = 0;
	Genome = Genome_ct_ga_flag;
	pos_indices_total = 0;
	all_shifts = 2;
	debug = 0;
	SEED = 24;//const
	half_SEED = SEED >> 1;
	BIG_SEED = 32;
	MIN_READ = 32;//const 
	first_bits = 0;//here it is the number of mism in SEED 
	out_amb = false;
	unmapped = false;
	A_rich = false;
	mism_thresh = 0;
	min_insert = 100;
	max_insert = 300;
	is_bs = "1";
	is_pe = "0";
	current_read_id = 0;

	int res = parse_options(argc, argv);
	if(mism_thresh == 0)
		max_num_shifts = 1;

	if(res == -1){
		usage();
		space_release();
		exit(0);
	}
	is_bs = "1";
	if(shift_delta != 32){
		//was changed
		if(shift_delta == 0)
			shift_delta = 32;
		else
			shift_delta = shift_delta << 1;//multiply by 2, convert from bases to bits
	}
	two_in_shift_delta = floor(log(static_cast<double>(shift_delta >> 1))/log(2.0));
	two_in_max_shift_delta = floor(log(static_cast<double>(max_shift_delta >> 1))/log(2.0));

	if(all_shifts != 2)
		all_shifts = 2;

	if(reads_file1.empty()){
		cout << "ERROR: file with reads is missing (option -s or -1 or -2)" << endl;
		space_release();
		exit(0);
	}
	if(is_pe == "1" && reads_file2.empty())
	{
		cout << "ERROR: file with mates 2 is missing for paired-end alignment (option -2)." << endl;
		space_release();
		exit(0);
	}
	if(output_pairs.empty()){
		cout << "ERROR: output file is not provided (option -o)" << endl;
		space_release();
		exit(0);
	}
	if(prefix.empty()){
		cout << "ERROR: path to BW-index is not provided (option -P)" << endl;
		space_release();
		exit(0);
	}
	if(BIG_SEED > 64)
		BIG_SEED = 64;

	if(first_bits > 1)
		first_bits = 1;

	if(res == -1 || prefix.empty()){
		usage();
		space_release();
		exit(0);
	}


	if(Genome == 1)
		out_pairs.open(output_pairs.c_str(), ios::out);

	string unm1 =  reads_file1 + ".unm";
	string unm2 = reads_file2 + ".unm";
	if(unmapped == true && (Genome == 1)){
		out_unmapped1.open(unm1.c_str(), ios::out);
		if(is_pe == "1"){
			out_unmapped2.open(unm2.c_str(), ios::out);
		}
	}//if unm

	string amb1 = reads_file1 + ".amb";
	string amb2 = reads_file2 + ".amb";
	if(out_amb == true && (Genome == 1)){
		out_amb1.open(amb1.c_str(), ios::out);
		if(is_pe == "1")
			out_amb2.open(amb2.c_str(), ios::out);
	}
		ofstream out_pairs;

	string output_mates1 = output_pairs + ".single_mates";


	if(is_pe == "1" && (Genome == 1)){
		out_mates1.open(output_mates1.c_str(), ios::out);
	}
	string rem = (prefix[prefix.length() - 1] == '/' ? "" : "/");

	string genome_repres("ACGT");
	if(Genome == 1)
		genome_repres = "CT";
	else if(Genome == 2)
		genome_repres = "GA";

	string input_ta_genome = prefix + rem + "ta.ta";
	string input_cg_genome = prefix + rem +  "cg.cg";
	string input_ns_genome = prefix + rem + genome_repres + ".ns";
	string input_chrom = prefix + rem + genome_repres + ".chr";
	string input_pos_indices = prefix + rem + genome_repres + ".pos_ind";
	string input_pos_sqr = prefix + rem + genome_repres + ".pos_num_sqr";
	string input_pos_occ = prefix + rem + genome_repres + ".pos_num_occ";
	string input_num_occ = prefix + rem + genome_repres + ".no";
	string input_num_sqr = prefix + rem + genome_repres + ".nosqr";
	string input_bwt = prefix + rem + genome_repres + ".bwt";
	string input_marked = prefix + rem + genome_repres + ".bwt_marked";
	string input_seeds = prefix + rem + genome_repres + ".seeds";

	in_bwt.open(input_bwt.c_str(), ios::in);
	if(!in_bwt){
		error_input(input_bwt);
	}
	in_num_occ.open(input_num_occ.c_str(), ios::in);
	if(!in_num_occ)
		error_input(input_num_occ);
	in_num_sqr.open(input_num_sqr.c_str(), ios::in);
	if(!in_num_sqr)
		error_input(input_num_sqr);
	if(Genome == 1){
		in_ta_genome.open(input_ta_genome.c_str(), ios::in);
		if(!in_ta_genome)
			error_input(input_ta_genome);
		in_cg_genome.open(input_cg_genome.c_str(), ios::in);
		if(!in_cg_genome)
			error_input(input_cg_genome);
	}
	in_ns_genome.open(input_ns_genome.c_str(), ios::in);
	if(!in_ns_genome)
		error_input(input_ns_genome);
	in_pos_indices.open(input_pos_indices.c_str(), ios::in);
	if(!in_pos_indices)
		error_input(input_pos_indices);
	in_pos_sqr.open(input_pos_sqr.c_str(), ios::in);
	if(!in_pos_sqr)
		error_input(input_pos_sqr);
	in_pos_occ.open(input_pos_occ.c_str(), ios::in);
	if(!in_pos_occ)
		error_input(input_pos_occ);
	in_chrom.open(input_chrom.c_str(), ios::in);	
	if(!in_chrom)
		error_input(input_chrom);
	in_marked.open(input_marked.c_str(), ios::in);
	if(!in_marked)
		error_input(input_marked);
	in_seeds.open(input_seeds.c_str(), ios::in);
	if(!in_seeds)
		error_input(input_seeds);

	_uli one = 1;
	min_read_len = 24;
	half_ui = 16;
	two_in_half_ui = 4;
	abyte = 8;
	SIZE = 64;//const: genome char per an unsigned long int
	two_in_Size = 6;
	MASK_SIZE = (one << two_in_Size) - 1;
	MASK_HALF = (one << 32) -1 ;
	block_size = 256;
	double_block = 256 + 256 + 2;//2 end of lines
	byte_size = 8;//byte size is characters(genome) per a byte
	two_in_byte = 3;//log_2(byte_size)

	block_byte_prod_divide = 11;//=log_2(256*8)
	block_divide = 8;//log_2(256)
	bytes = SIZE >> two_in_byte;//number of bytes per unsigned long int

	MASK_SEED = (one << SEED) -1;
	len_mer = SEED;
	block_32 = 1024;
	block_64 = SIZE << two_in_Size;//64*64
	two_in_Min_Read = 5;

	two_in_block_32 = 10;
	two_in_block_64 = 12;
	two_in_32 = 5;

	MASK_BYTE = (one << (byte_size)) -1;
	if(len_mer == SIZE)
		MASK_LMER = 0xFFFFFFFFFFFFFFFF;
	else if(len_mer < 32)
		MASK_LMER = (one << len_mer) - 1;//seed mask
	else{
		int dist = len_mer - 32;
		MASK_LMER = (((one << dist) - 1) << 32) | 0x00000000FFFFFFFF;	
	}

	dif_len_mer = SIZE - len_mer;
	MASK_READ = MASK_LMER;//for initialization only
	make_mask();
	make_mask_opp();

	input_info();//reads chroms info, C, pos_sizes and values for binary_total and ta-size

	two_in_Step = log(static_cast<float>(STEP))/log(static_cast<float>(2));
	block_256 = pow(2.0, 24.0);
	two_in_block_256 = 24;

	read_pos_sqr();

	read_pos_occ();

	read_pos_index();


	read_num_occ();

	read_num_occ_sqr();


	hash_table_size = pow(2.0, 24.0);
	num_occ_bytes.resize(hash_table_size);//2^16	
	for(long int i = 0; i < hash_table_size; i++){
        num_occ_bytes[i] = count_mism_long(i);
	}//for

	read_seeds();


	genome_byte_size = ((binary_total + 1) >> two_in_byte) + 1;

	read_genome(in_ns_genome, ns_genome);
	read_genome(in_marked, bwt_marked);

	if(Genome == 1){
		read_genome(in_ta_genome, ta_genome);
		read_genome(in_cg_genome, cg_genome);
	}

	read_bwt_genome();


	int apow_seed = 16;
	int alphabet_size = 4;
	int hash_small_size = pow(2.0, apow_seed + 0.0);
	num_occ_char.resize(hash_small_size);//2^SEED	
	for(_uli i = 0; i < hash_small_size; i++){
		vector< _usi > characters(alphabet_size, 0);
		count_char(i, characters, apow_seed);
        num_occ_char[i] = characters;

	}//for

}//Anchor()

void Anchor::count_char(_uli kmer, vector<_usi> & characters, int asize){

	for(int i = 0; i < asize; i += 2){
		_uli cur_char = kmer & mask[2];
		characters[cur_char]++;
		kmer >>= 2;
	}
}//count_char

void Anchor::read_genome(ifstream &in_genome, _uli * &agenome)
{

	agenome = new _uli[ta_size];
	assert(agenome != 0);

	long int buffer_size = block_256 << two_in_byte;//*8
	char *buffer = new char[buffer_size];
	assert(buffer != 0);

	in_genome.read(buffer, buffer_size);
	long int real_size = in_genome.gcount();

	long int gen_ind = 0;

	while(true){
		long int buf_ind = 0;
		while(buf_ind < real_size){
			_uli res = 0;
			for(int y = 0; y < 8 ; y++){
				res <<= byte_size;
				res |= int(buffer[buf_ind]) & MASK_BYTE;
				buf_ind++;
			}//for
			agenome[gen_ind] = res;
			gen_ind++;
		}//while buffer size
		if(in_genome.eof())
			break;
		in_genome.read(buffer, buffer_size);
		real_size = in_genome.gcount();
		if(real_size == 0)
			break;

	}//while true
	delete [] buffer;
//	cout << "finished reading bwt" << endl;
}//read_genome

void Anchor::read_bwt_genome()
{
	long int bwt_size = full_size + 1 ;
	bwt_genome = new _uli[bwt_size];
	assert(bwt_genome != 0);

	const _ui buffer_size = block_256 << two_in_byte;//*8
	char *buffer = new char[buffer_size];
	assert(buffer != 0);

	in_bwt.read(buffer, buffer_size);
	_uli real_size = in_bwt.gcount();

	long int bwt_ind = 0;

	while(true){
	  long int buf_ind = 0;
	  while(buf_ind < real_size){
		_uli res = 0;
		for(int y = 0; y < 8 ; y++){
			res <<= byte_size;
			res |= int(buffer[buf_ind]) & MASK_BYTE;
			buf_ind++;//buffer size is multiple of 8
		}//for
		bwt_genome[bwt_ind] = res;
		bwt_ind++;
	  }//while buffer size
	  if(in_bwt.eof())
		break;
	  in_bwt.read(buffer, buffer_size);
	  real_size = in_bwt.gcount();
	  if(real_size == 0)
		  break;
	}//while true
	delete [] buffer;

}//read_bwt_genome

void Anchor::make_mask(){
	_uli one = 1;
	mask.push_back(0);
	for(int i = 1; i <= SIZE; i++){
		_uli res = (one << i) - 1;
		mask.push_back(res);
	}//for
	mask[SIZE] = 0xFFFFFFFFFFFFFFFF;
}//make mask

void Anchor::make_mask_opp(){
	_uli one = 1;
	mask_opp.resize(SIZE);
	mask_opp[0] = 1;
	mask_opp_zero.resize(SIZE);
	mask_opp_zero[0] = ~mask_opp[0];
	for(int i = 1; i < SIZE; i++){
		mask_opp[i] = one << i;
		mask_opp_zero[i] = ~mask_opp[i];
	}//for

}//make mask

void Anchor::input_info(){

	in_chrom >> binary_total ;
	in_chrom >> ta_size;
	in_chrom >> full_binary_total;
	in_chrom >> full_size;
	in_chrom >> num_chroms ;	

	C.resize(5, 0);
	in_chrom >> C[0] >>  C[1] >> C[2] >> C[3] ;

	C[5] = C[0] + C[1] + C[2] + C[3] + C[4] + 1;
	C[4] = C[0] + C[1] + C[2] + C[3] + 1;
	C[3] = C[0] + C[1] + C[2] + 1;
	C[2] = C[0] + C[1] + 1;
	C[1] = C[0] + 1;
	C[0] = 1;

	in_chrom >> orig_gen_inL;
	in_chrom >> STEP ;
	in_chrom >> pos_indices_total;

	orig_num_sqr = orig_gen_inL >> two_in_block_64;
	orig_num = orig_gen_inL >> two_in_Size;
	
	map<long int, string>::iterator beg = chroms_names.begin();
	map<long int, string>::iterator fin = chroms_names.end();

	//index and name of chroms

	for(_ui i = 0; i < num_chroms; i++){
		_ui chr_id;
		string achr_name;
		in_chrom >> chr_id >> achr_name ;
		chroms_names.insert(make_pair(chr_id, achr_name));
	}

	//files with references
	for(_uli i = 0; i < num_chroms; i++){
		string afile;
		in_chrom >> afile;
		references_files.push_back(afile);
	}//for i
	//sizes of chroms in bits: each bit per char
	for(_ui i = 0; i < num_chroms; i++){
		_ui achr_size;
		in_chrom >> achr_size;
		size_chrom.push_back(achr_size);
	}
	//starts of chroms in bits
	for(_ui i = 0; i < num_chroms; i++){
		_ui achr_start ;
		in_chrom >> achr_start;
		starts_size_chrom.push_back(achr_start);
	}

}//input_info
//lookup8.c, by Bob Jenkins, January 4 1997, Public Domain.

void Anchor::retreive_seed(_ui ind, _uli &sp , _uli &ep){

	_uli res = seeds[ind];

	ep = res & mask[32];
	sp = res >> 32;

}//retreive_seed

void Anchor::read_seeds()
{
	seeds = new _uli[hash_table_size];
	_uli buffer_size = hash_table_size << two_in_byte;//*8
	char *buffer = new char[buffer_size];
	in_seeds.read(buffer, buffer_size);
	_uli read_char = static_cast<_uli>(in_seeds.gcount());
	if(read_char < buffer_size){
		cout << "\nERROR: Unexpected size of seeds file" << endl;
		space_release();
		exit(0);
	}
	_uli buf_ind = 0;

	for(_uli i = 0; i < hash_table_size; i++){
		_uli res = 0;
		for(_ui j = 0; j < 8; j++){
			//sp 4 bytes and ep 4 bytes
			res <<= 8;
			res |= (int(buffer[buf_ind]) & MASK_BYTE);
			buf_ind++;
		}//for j
		seeds[i] = res;
	}//for i
	delete [] buffer;
}//read_seeds

void Anchor::read_pos_sqr(){
	_uli full_binary = ta_size << two_in_Size;
	_uli total_occ = full_binary >> two_in_block_64;
	if((total_occ & mask[two_in_block_64]) > 0)
		total_occ++;

	const _uli buffer_size = total_occ << 2; //*4 for unsigned int
	pos_num_sqr = new _ui[total_occ];
	assert(pos_num_sqr != 0);

	char *buffer = new char[buffer_size];
	assert(buffer != 0);

	in_pos_sqr.read(buffer, buffer_size);
	_uli read_char = static_cast<_uli>(in_pos_sqr.gcount());
	if(read_char < buffer_size){
		cout << "\nERROR: Unexpected size of positions' sqr occ file" << endl;
		space_release();
		exit(0);
	}
	_uli buffer_ind = 0;
	for(_uli i = 0; i < total_occ; i++){
		_uli res = 0;
		for(_uli y = 0; y < 4; y++){//4 is bytes in unsigned int
			res <<= byte_size;
			char x = buffer[buffer_ind];
			buffer_ind++;
			res |= (int(x) & MASK_BYTE);
		}//for y	
		pos_num_sqr[i] = res;
	}//for i

	delete [] buffer;
	in_pos_sqr.close();
}//read_pos_sqr

void Anchor::read_pos_occ(){
	_uli total_occ = ta_size;
	const _uli buffer_size = total_occ << 1; //*2 size of unsigned short int
	char *buffer = new char[buffer_size];
	in_pos_occ.read(buffer, buffer_size);
	_uli read_char = in_pos_occ.gcount();
	if(read_char < buffer_size){
		cout << "\nERROR: Unexpected size of positions' keys file" << endl;
		space_release();
		exit(0);
	}

	pos_num_occ = new _usi[total_occ];
	assert(pos_num_occ != 0);

	_uli buffer_ind = 0;
	for(_uli i = 0; i < total_occ; i++){
		_uli res = 0;
		for(_uli y = 0; y < 2; y++){//2 is bytes in unsigned short int
			res <<= byte_size;
			char x = buffer[buffer_ind];
			buffer_ind++;
			res |= (int(x) & MASK_BYTE);
		}//for y	
		pos_num_occ[i] = res;
	}//for i

	delete [] buffer;
	in_pos_occ.close();
}

void Anchor::read_num_occ_sqr()
{
	_uli full_binary = ta_size << two_in_Size;
	_uli total_occ = full_binary >> two_in_block_64;
	if((total_occ & mask[two_in_block_64]) > 0)
		total_occ++;

	const _uli buffer_size = total_occ << 4; //*4 *4 for 4 char each 4 bytes
	char *buffer = new char[buffer_size];
	assert(buffer != 0);

	in_num_sqr.read(buffer, buffer_size);
	_uli read_char = static_cast<_uli>(in_num_sqr.gcount());
	if(read_char < buffer_size){
		cout << "\nERROR: Unexpected size of positions' keys file" << endl;
		space_release();
		exit(0);
	}
	vector<_ui> dum(4, 0);
	num_occ_sqr.resize(total_occ, dum);
	_uli buffer_ind = 0;
	for(_uli i = 0; i < total_occ; i++){
		_uli res = 0;
		for(_uli y = 0; y < 4; y++){//4 is bytes in unsigned int
			res <<= byte_size;
			char x = buffer[buffer_ind];
			buffer_ind++;
			res |= (int(x) & MASK_BYTE);
		}//for y	
		num_occ_sqr[i][0] = res;
		res = 0;
		for(_uli y = 0; y < 4; y++){//4 is bytes in unsigned int
			res <<= byte_size;
			char x = buffer[buffer_ind];
			buffer_ind++;
			res |= (int(x) & MASK_BYTE);
		}//for y	
		num_occ_sqr[i][1] = res;
		res = 0;
		for(_uli y = 0; y < 4; y++){//4 is bytes in unsigned int
			res <<= byte_size;
			char x = buffer[buffer_ind];
			buffer_ind++;
			res |= (int(x) & MASK_BYTE);
		}//for y	
		num_occ_sqr[i][2] = res;
		res = 0;
		for(_uli y = 0; y < 4; y++){//4 is bytes in unsigned int
			res <<= byte_size;
			char x = buffer[buffer_ind];
			buffer_ind++;
			res |= (int(x) & MASK_BYTE);
		}//for y	
		num_occ_sqr[i][3] = res;
	}//for i
	
	delete [] buffer;
}//read_num_occ_sqr

void Anchor::read_num_occ()
{
	//ta_size because we count number of occ of a char in bwt of N bases length
	//the count is in bases not in bits: there are ta_size of 64-bases words
	_uli total_occ = ta_size ;//*4 for four characters
	num_occ.resize(4);
	for(int y = 0; y < 4; y++){
		num_occ[y] = new unsigned short int[total_occ];
		assert(num_occ[y] != 0);
	}//for y

	const _ui buffer_size = block_256 << two_in_byte;//*8: 4char each 2 bytes
	char *buffer = new char[buffer_size];
	assert(buffer != 0);

	in_num_occ.read(buffer, buffer_size);
	_uli real_size = in_num_occ.gcount();
 
	_uli num_occ_ind = 0;

	while(true){//while reading entire file

		_uli buffer_ind = 0;
		while(buffer_ind < real_size){
			//As
			_ui res = 0;
			for(_uli y = 0; y < 2; y++){//2 is bytes in unsigned short int
				res <<= byte_size;
				char x = buffer[buffer_ind];
				buffer_ind++;
				res |= (int(x) & MASK_BYTE);
			}//for y	
			num_occ[0][num_occ_ind] = res;

			//Cs
			res = 0;
			for(_uli y = 0; y < 2; y++){//2 is bytes in unsigned short int
				res <<= byte_size;
				char x = buffer[buffer_ind];
				buffer_ind++;
				res |= (int(x) & MASK_BYTE);
			}//for y	
			num_occ[1][num_occ_ind] = res;

			//Gs
			res = 0;
			for(_uli y = 0; y < 2; y++){//2 is bytes in unsigned short int
				res <<= byte_size;
				char x = buffer[buffer_ind];
				buffer_ind++;
				res |= (int(x) & MASK_BYTE);
			}//for y	
			num_occ[2][num_occ_ind] = res;

			//Ts
			res = 0;
			for(_uli y = 0; y < 2; y++){//2 is bytes in unsigned short int
				res <<= byte_size;
				char x = buffer[buffer_ind];
				buffer_ind++;
				res |= (int(x) & MASK_BYTE);
			}//for y	
			num_occ[3][num_occ_ind] = res;
			num_occ_ind++;

		}//while buffer size
		if(in_num_occ.eof())
			break;
		in_num_occ.read(buffer, buffer_size);
		real_size = in_num_occ.gcount();
		if(real_size == 0)
			break;
	}//while entire file

	delete [] buffer;
}//read_num_occ

void Anchor::read_pos_index()//index of pos_index in counts not Bytes
{
	_ui total_keys = pos_indices_total;

	//total bytes to read = total_keys * 4 for _ui
	const _ui buffer_size = block_256 << 2;//*4
	char *buffer = new char[buffer_size];
	assert(buffer != 0);

	in_pos_indices.read(buffer, buffer_size);
	_uli real_size = in_pos_indices.gcount();

	pos_indices = new _ui[total_keys];
	assert(pos_indices != 0);

	long int last_lmer_char = 0;
	
	long int pos_indices_ind = 0;
	while(true){
		long int buf_ind = 0;
		while( buf_ind < real_size){
			_ui res = 0;
			for(_ui y = 0; y < 4; y++){//4 is bytes in unsigned int
				res <<= byte_size;
				char x = buffer[buf_ind];
				buf_ind++;
				res |= (int(x) & MASK_BYTE);
			}//for y
			pos_indices[pos_indices_ind] = res;
			pos_indices_ind++;
		}//while buffer size

		if(in_pos_indices.eof())
			break;
		in_pos_indices.read(buffer, buffer_size);
		real_size = in_pos_indices.gcount();

		if(real_size == 0)
				break;	
	}//while
	delete [] buffer;

}//read_pos_index


//NEXT
/*original
void Anchor::exact_match(_uli ta_read, _uli &sp, _uli &ep, _uli read_len, _uli &remainder)//sp=1, ep = 0, remainer = 0: init
{
	_uli ch = ta_read & mask[1];
	ta_read >>= 1;
	int i = read_len - 1;
	sp = C[ch];
	ep = C[ch + 1] - 1;
	while( (sp < ep) && (i > 0)){
		ch = ta_read & mask[1];
		ta_read >>= 1;
		sp = C[ch] + Occ(ch, sp -1);
		ep = C[ch] + Occ(ch, ep) - 1;
		i--;
	}//while
	remainder = i;
}//exact_match

*/


_uli Anchor::find_gen_pos(_uli sp, _uli remainder)
{
	//remainder is in bases

	_uli *ptr_sp = &sp;
	if(STEP == 1)
		return (pos_indices[(*ptr_sp) - 1] - remainder);

	_uli gen_ind = 0;

	_uli count_lfmap = 0;
	while(true){
		_uli is_marked = get_marked_char(ptr_sp);
		if(is_marked > 0){
			gen_ind = pos_indices[pos_Occ(*ptr_sp) - 1];//pos_Occ returns count, index will be 1 less
			break;
		}//marked
		else{
			count_lfmap++;
			lf_map(ptr_sp);
		}//else
	}//while
	//remainder is in bases
	return (gen_ind + count_lfmap - remainder);

}//find_gen_pos

void Anchor::exact_match(_uli ta_read, _uli &sp, _uli &ep, _uli read_len, _uli &remainder, 
	_uli &valid_sp, _uli &valid_ep)//sp=1, ep = 0, remainer = 0: init
{
	//this function continues reading a read: either a long read
	//or after matching the seed
	//remainder is the rest of the read after seed

	//read_len is in bases 
	//remainder is in bases

	int i = read_len ;
	while( (sp < ep) && (i > 0)){
		_uli ch = ta_read & mask[2];
		ta_read >>= 2;
		_uli prev_sp = sp -1;
		_uli *ptr_sp = &prev_sp;
		_uli prev_ep = ep;
		_uli *ptr_ep =  &prev_ep;
		sp = C[ch] + Occ(ch, ptr_sp);
		ep = C[ch] + Occ(ch, ptr_ep) - 1;
		if(sp <= ep){
			valid_sp = sp;
			valid_ep = ep;
		}
		i--;
	}//while
	remainder = remainder - (read_len - i);
}//exact_match

void Anchor::exact_match_seed(_uli ta_read, _uli &sp, _uli &ep, _uli read_len, _uli &remainder)//sp=1, ep = 0, remainer = 0: init
{
	//this function continues reading a read: either a long read
	//or after matching the seed
	//remainder is the rest of the read after seed

	//read_len is in bases 
	//remainder is in bases

	int i = read_len ;
	while( (sp <= ep) && (i > 0)){
		_uli ch = ta_read & mask[2];
		ta_read >>= 2;
		_uli prev_sp = sp -1;
		_uli *ptr_sp = &prev_sp;
		_uli prev_ep = ep;
		_uli *ptr_ep =  &prev_ep;
		sp = C[ch] + Occ(ch, ptr_sp);
		ep = C[ch] + Occ(ch, ptr_ep) - 1;
		i--;
	}//while
	remainder = remainder - (read_len - i);
}//exact_match_seed

_uli Anchor::Occ(_uli ch, _uli *sp){
	
	_uli double_sp = (*sp) << 1;
	_uli full_ind = (double_sp) >> two_in_Size;
	_uli full_bits = (double_sp) & mask[two_in_Size];
	_uli num_cur = get_bwt_lmer(full_ind, full_bits + 2, ch);
	//is full_ind in the first or second half of the original 64-bit sp range?
	//number of sp (1-bit count) before cur block
	_uli bl_ind = (*sp) >> two_in_Size;
	_uli sum_bl_ind = bl_ind << two_in_Size;//not same as sp because of remainder
	_uli full_sum_bl_ind = (sum_bl_ind << 1) + SIZE;
	if(double_sp >= full_sum_bl_ind){
		num_cur += get_bwt_lmer(full_ind - 1, SIZE, ch);
	}

	_uli block_ind_sqr = (*sp) >> two_in_block_64;
	_uli num_a_sqr = (block_ind_sqr == 0 ? 0 : num_occ_sqr[block_ind_sqr - 1][ch]);


    _uli bl_inside_ind =  bl_ind & mask[two_in_Size];//index inside of a conceptual block
	_uli num_prev_bl = (bl_inside_ind == 0 ? 0 : num_occ[ch][bl_ind - 1]);


	//this is true only for A character, becaus EOS($) char also was represented as A
	//and because this was not counted
	if((ch == 0) && (orig_num == bl_ind) && (orig_gen_inL <= (*sp)))
		num_cur--;

	num_a_sqr += num_prev_bl + num_cur;	
	

	return num_a_sqr;
}//Occ

_uli Anchor::get_bwt_lmer(_uli cur_byte, _uli aread_len, _uli ch){
	//aread_len here is in bits not bases

        _uli bwt_lmer = bwt_genome[cur_byte];
        _uli count_ones = 0;
		_uli ashift = (SIZE - aread_len);
		bwt_lmer >>= ashift; 
        for(int i = 0; i < 4; i++){
                count_ones += num_occ_char[bwt_lmer & mask[16]][ch];//64-bit word is subdivided into 16bit sub-words
                bwt_lmer >>= 16;
        }
		if(ch == 0)
			count_ones -= ((SIZE - aread_len) >> 1);//filled in zeros at init bwt_lmer, divide by two = number of A/N/G
        return count_ones;
}//get_bwt_lmer

_uli Anchor::pos_Occ(_uli &sp){

	_uli bl_ind = (sp) >> two_in_Size;
	_uli ind_cur = (sp) & mask[two_in_Size];
	_uli num_cur = get_pos_lmer(bl_ind, ind_cur + 1);//for Ts returns number of ones

	_uli block_ind_sqr = (sp) >> two_in_block_64;
	_uli num_a_sqr = (block_ind_sqr == 0 ? 0 : pos_num_sqr[block_ind_sqr - 1]);
    _uli bl_inside_ind =  bl_ind & mask[two_in_Size];//index inside of a conceptual block
	_uli num_prev_bl = (bl_inside_ind == 0 ? 0 : pos_num_occ[bl_ind - 1]);

	num_a_sqr += num_prev_bl + num_cur;	
	
	return num_a_sqr;
}//pos_Occ

_uli Anchor::get_pos_lmer(_uli &cur_byte, _uli aread_len)
{
    _uli bwt_lmer = bwt_marked[cur_byte];
	_uli count_ones = 0;
	_uli ashift = SIZE - aread_len;
	bwt_lmer >>= ashift;
    count_ones += num_occ_bytes[bwt_lmer & mask[SEED]];
    bwt_lmer >>= SEED;
	count_ones += num_occ_bytes[bwt_lmer & mask[SEED]];
	count_ones += num_occ_bytes[bwt_lmer >> SEED];
        
        return count_ones;
}//get_pos_lmer


_uli Anchor::get_marked_char(_uli *ind){

	if((*ind) > binary_total)//bwt size = binary_total + 1
		return 0;
	_uli ta_ind = (*ind) >> two_in_Size;//ind inside bwt_marked
	_uli bwt_lmer = bwt_marked[ta_ind];
	_uli ind_inside_Size = (*ind) & mask[two_in_Size];
	_uli ashift = SIZE - ind_inside_Size - 1;
	_uli res = (bwt_lmer >> ashift) & mask[1];
	return res;
}//get_marked_char

void Anchor::lf_map(_uli * &sp)
{
	_uli ch = get_bwt_char(sp);
	(*sp) = C[ch] + Occ(ch, sp) - 1;
}//lf_map

_uli Anchor::get_bwt_char(_uli *sp){

	_uli full_ind = ((*sp) << 1) >> two_in_Size;
	_uli bwt_lmer = bwt_genome[full_ind];
	_uli full_bits = (((*sp) << 1) & mask[two_in_Size]) + 2;

	if((full_ind) >= full_size)
		return 0;
	_uli ashift = SIZE - full_bits;
	_uli res = (bwt_lmer >> ashift) & mask[2];
	return res;
}//get_bwt_char

_uli Anchor::get_ns_lmer(_uli ind){

	if(ind > binary_total)//bwt size = binary_total + 1
		return 0;
	_uli ta_ind = ind >> two_in_Size;//ind inside bwt
	_uli ns_lmer = ns_genome[ta_ind];
	_uli ind_inside_Size = ind & mask[two_in_Size];
	_uli ashift = (SIZE - ind_inside_Size - 1);
	_uli res = (ns_lmer >> ashift ) & mask[1];
	return res;
}//get_ns_lmer

////////////////////////// LONG READS

void Anchor::convert_gen_mer_ta(unsigned long int &ta_gen_lmer,
					 unsigned long int pos,
					 unsigned long int aread_len, const Anchor &anc)
{
	ta_gen_lmer = 0;
	if(pos >= binary_total){
		cout << "ERROR reading from ta-genome: pos index is out of boundary" << endl;
		space_release();
		exit(0);
		return;
	}
	//current binary char inside current block: there 8 characters fit in one binary characters
	//(pos >> two_in_byte) = pos / byte_size = number of binary characters needed to cover this pos
	_uli gen_ind = (pos >> two_in_Size) ;//index of 64-bit word

	_uli prev = anc.ta_genome[gen_ind];
	_uli next = (gen_ind + 1 >= ta_size ? 0 : anc.ta_genome[gen_ind + 1]);

	_uli ind_inside_byte = pos & mask[two_in_Size];//pos of genome char inside 64-bit word	
	_uli bits_in_left = SIZE - ind_inside_byte;

	_uli left = prev & mask[bits_in_left];
	if(bits_in_left >= aread_len){
		ta_gen_lmer = left >> (bits_in_left - aread_len);
		return;
	}
	_uli right = next >> bits_in_left;
	ta_gen_lmer = ((left << (SIZE - bits_in_left)) | right) >> (SIZE - aread_len);

}//convert_gen_mer_ta


void Anchor::convert_gen_mer_cg(unsigned long int &ta_gen_lmer,
					 unsigned long int pos,
					 unsigned long int aread_len, const Anchor &anc)
{
	ta_gen_lmer = 0;
	if(pos >= binary_total){
		cout << "ERROR reading from ta-genome: pos index is out of boundary" << endl;
		space_release();
		exit(0);
		return;
	}
	//current binary char inside current block: there 8 characters fit in one binary characters
	//(pos >> two_in_byte) = pos / byte_size = number of binary characters needed to cover this pos
	_uli gen_ind = (pos >> two_in_Size) ;//index of 64-bit word

	_uli prev = anc.cg_genome[gen_ind];
	_uli next = (gen_ind + 1 >= ta_size ? 0 : anc.cg_genome[gen_ind + 1]);

	_uli ind_inside_byte = pos & mask[two_in_Size];//pos of genome char inside 64-bit word	
	_uli bits_in_left = SIZE - ind_inside_byte;

	_uli left = prev & mask[bits_in_left];
	if(bits_in_left >= aread_len){
		ta_gen_lmer = left >> (bits_in_left - aread_len);
		return;
	}
	_uli right = next >> bits_in_left;
	ta_gen_lmer = ((left << (SIZE - bits_in_left)) | right) >> (SIZE - aread_len);

}//convert_gen_mer_cg

void Anchor::convert_gen_mer_ta(vector<_uli> &ta_gen_read,
					 unsigned long int pos,
					 unsigned long int aread_len, const Anchor &anc)
{
	_uli ta_gen_lmer = 0;

	//current binary char inside current block: there 8 characters fit in one binary characters
	//(pos >> two_in_byte) = pos / byte_size = number of binary characters needed to cover this pos
	_uli cur_byte = (pos >> two_in_Size) ;//index of the first byte
	_uli ind_inside_byte = pos & mask[two_in_Size];//pos of genome char inside byte-block	
	_uli bits_in_first_byte = SIZE - ind_inside_byte;
	_uli new_len = aread_len - bits_in_first_byte;
	_uli bits_in_last_byte = new_len & mask[two_in_Size];
	_uli bytes_rest = (new_len >> two_in_Size) + ( bits_in_last_byte > 0 ? 1 : 0);

	_uli num_bytes = bytes_rest + 1;
	if((cur_byte + num_bytes - 1) >= ta_size){
		ta_gen_read.resize((aread_len >> two_in_Size) + ((aread_len & mask[two_in_Size]) > 0 ? 1 : 0), 0);
		return;
	}
	ta_gen_read.resize(num_bytes, 0);
	ta_gen_read[0] = anc.ta_genome[cur_byte] & mask[bits_in_first_byte];

	int asize = 1, j = cur_byte + 1;
	while(asize < num_bytes){
		ta_gen_read[asize] = anc.ta_genome[j];
		asize++;
		j++;
	}//while
	//shift the last byte;
    if(bits_in_last_byte > 0){
	    ta_gen_read[asize - 1] >>= (SIZE - bits_in_last_byte);
		shift_back(ta_gen_read, asize, bits_in_last_byte);
	}
	reverse(ta_gen_read.begin(), ta_gen_read.end());
	int correct_size = (aread_len >> two_in_Size) + ((aread_len & mask[two_in_Size]) > 0 ? 1 : 0);
	if(asize > correct_size)
		ta_gen_read.resize(correct_size);

}//convert_gen_mer_ta

void Anchor::convert_gen_mer_cg(vector<_uli> &ta_gen_read,
					 unsigned long int pos,
					 unsigned long int aread_len, const Anchor &anc)
{
_uli ta_gen_lmer = 0;

	//current binary char inside current block: there 8 characters fit in one binary characters
	//(pos >> two_in_byte) = pos / byte_size = number of binary characters needed to cover this pos
	_uli cur_byte = (pos >> two_in_Size) ;//index of the first byte
	_uli ind_inside_byte = pos & mask[two_in_Size];//pos of genome char inside byte-block	
	_uli bits_in_first_byte = SIZE - ind_inside_byte;
	_uli new_len = aread_len - bits_in_first_byte;
	_uli bits_in_last_byte = new_len & mask[two_in_Size];
	_uli bytes_rest = (new_len >> two_in_Size) + ( bits_in_last_byte > 0 ? 1 : 0);

	_uli num_bytes = bytes_rest + 1;
	if((cur_byte + num_bytes - 1) >= ta_size){
		ta_gen_read.resize((aread_len >> two_in_Size) + ((aread_len & mask[two_in_Size]) > 0 ? 1 : 0), 0);
		return;
	}

	ta_gen_read.resize(num_bytes, 0);
	ta_gen_read[0] = anc.cg_genome[cur_byte] & mask[bits_in_first_byte];

	int asize = 1, j = cur_byte + 1;
	while(asize < num_bytes){
		ta_gen_read[asize] = anc.cg_genome[j];
		asize++;
		j++;
	}//while

	//shift the last byte;
    if(bits_in_last_byte > 0){
	    ta_gen_read[asize - 1] >>= (SIZE - bits_in_last_byte);
		shift_back(ta_gen_read, asize, bits_in_last_byte);
	}
	reverse(ta_gen_read.begin(), ta_gen_read.end());
	int correct_size = (aread_len >> two_in_Size) + ((aread_len & mask[two_in_Size]) > 0 ? 1 : 0);
	if(asize > correct_size)
		ta_gen_read.resize(correct_size);
	
}//convert_gen_mer_cg

void Anchor::align_linear(const _uli &ta, _uli &sp, _uli &ep, _uli read_len1,  _uli &remainder)
{
	// remainder = read_len in bases
	sp = 0; ep = 0;

	_uli ta_seed = ta & mask[SEED];
	retreive_seed(ta_seed, sp, ep);
	remainder = read_len1 -  half_SEED;
	_uli ta_rest = ta  >> SEED;
	exact_match_seed(ta_rest, sp, ep, remainder, remainder);

}//align_linear

void Anchor::align_linear_seed(vector<_uli> ta, _uli &sp, _uli &ep, _uli read_len1, _uli &remainder, _uli total_bits)
{
	//ta must be not reference but a copy because we need it later in program and are going to change it here
	//first entries of ta contain full 64-bit words
	int size_ta = ta.size();
	vector<long int> lengths(size_ta, half_word);
	int read_rest = read_len1 - ((size_ta - 1) << two_in_32);
	lengths[size_ta - 1] = read_rest;

	int bl = total_bits >> two_in_Size;//current 64-bit block
	_uli ashift = total_bits & mask[two_in_Size];
	sp = 0 ;
	ep = 0;
	int full_remainder = read_len1 - (total_bits >> 1);//read_len1 in bases, total_bits in bits
	
	_uli ta_rest = (ta[bl] >> (ashift));
	int rest_len = lengths[bl] - (ashift >> 1);
	remainder = rest_len;
	bl++;//points to next not fully used
	if(remainder < half_SEED){
		fill_ta_rest(ta, lengths, bl, remainder, ta_rest, size_ta);
		rest_len = remainder;
	}
		if(sp >= ep){
			_uli ta_seed = ta_rest & MASK_SEED;
			ta_rest >>= SEED;
			rest_len -= half_SEED;
			full_remainder -= half_SEED;
			remainder -= half_SEED;
			retreive_seed(ta_seed, sp, ep);
		}//if
	while(true){

		exact_match_seed(ta_rest, sp, ep, rest_len, remainder);
		int mapped = rest_len - remainder;
		if(mapped == half_word)
			ta_rest = 0;
		else
			ta_rest >>= (mapped << 1);//mapped in bases
		full_remainder -= mapped;
		rest_len -= mapped;

		if(sp > ep){//found mism, for k=2, seed did not align
			break;
		}
		if(full_remainder == 0)
			break;
		if(remainder < half_SEED){
			fill_ta_rest(ta, lengths, bl, remainder, ta_rest, size_ta);
			rest_len = remainder;
		}

	}//while
	remainder = full_remainder;
}//align_linear for long reads

void Anchor::align_linear(vector<_uli> ta, _uli &sp, _uli &ep, _uli read_len1, _uli &remainder, _uli total_bits)
{
	//ta must be not reference but a copy because we need it later in program and are going to change it here
	//first entries of ta contain full 64-bit words
	_uli prev_sp = 0, prev_ep = 0;
	int size_ta = ta.size();
	vector<long int> lengths(size_ta, half_word);
	int read_rest = read_len1 - ((size_ta - 1) << two_in_32);
	lengths[size_ta - 1] = read_rest;

	int bl = total_bits >> two_in_Size;//current 64-bit block
	_uli ashift = total_bits & mask[two_in_Size];
	sp = 0 ;
	ep = 0;
	int full_remainder = read_len1 - (total_bits >> 1);//read_len1 in bases, total_bits in bits
	
	_uli ta_rest = (ta[bl] >> (ashift));
	int rest_len = lengths[bl] - (ashift >> 1);
	remainder = rest_len;
	bl++;//points to next not fully used
	if(remainder < half_SEED){
		fill_ta_rest(ta, lengths, bl, remainder, ta_rest, size_ta);
		rest_len = remainder;
	}

	while(true){
		if(sp >= ep){
			_uli ta_seed = ta_rest & MASK_SEED;
			ta_rest >>= SEED;
			rest_len -= half_SEED;
			full_remainder -= half_SEED;
			remainder -= half_SEED;
			retreive_seed(ta_seed, sp, ep);
		}//if
		exact_match(ta_rest, sp, ep, rest_len, remainder, prev_sp, prev_ep);
		int mapped = rest_len - remainder;
		if(mapped == half_word)
			ta_rest = 0;
		else
			ta_rest >>= (mapped << 1);//mapped in bases
		full_remainder -= mapped;
		rest_len -= mapped;
		if(sp == ep){//mapped uniquelly
			break;
		}
		if(sp > ep){//found mism, for k=2, it means, do next shift
			break;
		}
		if(full_remainder == 0)
			break;
		if(remainder < half_SEED){
			fill_ta_rest(ta, lengths, bl, remainder, ta_rest, size_ta);
			rest_len = remainder;
		}

	}//while
	remainder = full_remainder;
	if((sp > ep) && (read_len1 - remainder - total_bits + 1 >= BIG_SEED)){
		sp = prev_sp;
		ep = prev_ep;
		remainder++;
	}
}//align_linear for long reads
void Anchor::fill_ta_rest(vector<_uli> &ta, vector<long int> &lengths, int &bl, _uli &remainder, _uli &ta_rest, int &asize)
{

	long int unfilled = SIZE - (remainder << 1);//remainder is in bases
	while((bl < asize) && (unfilled > 0)){
		int next_len = lengths[bl];
		_uli ta_next = ta[bl];
		ta_next <<= (remainder << 1);
		ta_rest |= ta_next;
		if((next_len << 1) <= unfilled ){
			unfilled -= (next_len << 1);
			remainder += next_len;
			lengths[bl] = 0;
			ta[bl] >>= (next_len << 1);
			bl++;
		}
		else{
			remainder += (unfilled >> 1);
			ta[bl] >>= unfilled;
			lengths[bl] -= (unfilled >> 1);
			unfilled = 0;
		}
		
	}//while
}//fill_ta_rest called from align_linear for long reads


void Anchor::map_pos(const _uli &sp, const _uli &ep, const _uli &ta_read1, const _uli &read_len1, const _uli &c_read1, 
		const bool &forward, bool &pair_ambiguous, const _uli &remainder, Mates &mates_pairs,
		const _uli &ns_read1, bool map_mism, const Anchor &anc)
{
	_ui start1 = sp;
	_ui end1 = ep + 1;
	long int total = ep - sp + 1;
	if(total > 1000){
		return;
	}

	while(start1 < end1){
		_uli ns_check = get_ns_lmer(start1);//checks if first 24 bits of gen-lmer has Ns
		if(ns_check == 0){
			_ui pos1 = find_gen_pos(start1, remainder);
			if((pos1 > 0) && ((pos1 + read_len1) <= binary_total)){ 
				bool cg_mism1 = false;
				_uli ta_check = 0;
				int mism1 = 0;


					//for bs-reads we need to verify T->C and A->G match for different strands
					mism1 = cg_match(read_len1, pos1, ta_read1, c_read1, ta_check, forward, cg_mism1, ns_read1, anc);//returns total mism ta+cg+ns


//for short reads, fixed length = 32 bases, we don't need ta-check because we have already did this with BWT alignment
				if(mism1 <= mism_thresh)
					ta_match(read_len1, pos1, ta_read1, ta_check, ns_read1, mism1, anc);

				if(mism1 <= mism_thresh){
					char strand = '+';
					if(forward == false)
						strand = '-';
					update_singles(mates_pairs, strand, pos1, mism1, pair_ambiguous, map_mism);		
				}//both reads passed cg-check
		
				if(pair_ambiguous == true)			
					break;
			}//if pos within genome
		}//if no Ns in the genome at that position

		start1++;
	}//for forward read's list
}//map_pos



void Anchor::map_pos(const _uli &sp, const _uli &ep, const vector<_uli> &ta_read1, const _uli &read_len1, const vector<_uli> &c_read1, 
		const bool &forward, bool &pair_ambiguous, const _uli &remainder, Mates &mates_pairs,
		const vector<_uli> &ns_read1, bool map_mism, const Anchor &anc)
{
	_ui start1 = sp;
	_ui end1 = ep + 1;//must be so, in case sp = ep , don;t do twice
	int asize = ta_read1.size();

	long int total = ep - sp + 1;
	if(total > 1000){
		return;
	}

	while(start1 < end1){
		_uli ns_check = get_ns_lmer(start1);//checks if first 24 bits of gen-lmer has Ns
		if(ns_check == 0){
			_ui pos1 = find_gen_pos(start1, remainder);
			if((pos1 > 0) && ((pos1 + read_len1) <= binary_total)){ 
				bool cg_mism1 = false;
				vector<_uli> ta_check(asize, 0);
				int mism1 = 0;
				
	
				mism1 = cg_match(read_len1, pos1, ta_read1, c_read1, ta_check, forward, cg_mism1, ns_read1, anc);

				if(mism1 <= mism_thresh ){
					//ta-check: need only for partially mapped reads
					ta_match(read_len1, pos1, ta_read1, ta_check, ns_read1, mism1, anc);
				}

				if(mism1 <= mism_thresh){
					char strand = '+';
					if(forward == false)
						strand = '-';
					update_singles(mates_pairs, strand, pos1, mism1, pair_ambiguous, map_mism);		
				}//both reads passed cg-check
		
				if(pair_ambiguous == true)			
					break;
			}//if pos is within the genome size
		}//if no Ns in the genome at that position
		start1++;
	}//for forward read's list
}//map_pos
	
void Anchor::get_all_backtrace(const vector<_uli> ta_seed, vector< vector<_uli> > &all_mism, 
		_uli mism_ind, bool forward, int &num_mism)
{
	_uli zero = 0, one = 1, two = 2, three = 3;

	_uli shift_bits = mism_ind;
	_uli ta_mism = 0;
	if(mism_ind < half_word){
		shift_bits <<= 1;
		ta_mism = ta_seed[0];
	}
	else{
		shift_bits = (mism_ind - half_word) << 1;
		ta_mism = ta_seed[1];
	}

	vector<_uli> atemp_seed(2);

	_uli ch = (ta_mism >> (shift_bits)) & mask[2];
	_uli amask = ~(three << (shift_bits)); 
	if((forward == true && A_rich == false) || (forward == false && A_rich == true)){
		switch(ch){
			case 0: 
				atemp_seed[0] = (ta_mism & amask) | (two << (shift_bits)) ; 
				atemp_seed[1] = (ta_mism & amask) | (three << (shift_bits)) ;
				num_mism = 2;
				break;
			case 2: 
				atemp_seed[0] = (ta_mism & amask) | (zero << (shift_bits)) ;
				atemp_seed[1] = (ta_mism & amask) | (three << (shift_bits)) ;
				num_mism = 2;
				break;
			case 3:
				atemp_seed[0] = (ta_mism & amask) | (zero << (shift_bits)) ; 
				atemp_seed[1] = (ta_mism & amask) | (two << (shift_bits)) ;
				num_mism = 2;
				break;
			default: num_mism = 0; break;
		}//switch
	}//forward
	else{
		switch(ch){
			case 0: 
				atemp_seed[0] = (ta_mism & amask) | (one << (shift_bits)) ; 
				atemp_seed[1] = (ta_mism & amask) | (three << (shift_bits)) ;
				num_mism = 2;
				break;
			case 1: 
				atemp_seed[0] = (ta_mism & amask) | (zero << (shift_bits)) ; 
				atemp_seed[1] = (ta_mism & amask) | (three << (shift_bits)) ;
				num_mism = 2;
				break;
			case 3:
				atemp_seed[0] = (ta_mism & amask) | (zero << (shift_bits)) ; 
				atemp_seed[1] = (ta_mism & amask) | (one << (shift_bits)) ;
				num_mism = 2;
				break;
			default: num_mism = 0; break;
		}//switch	
	
	}//rev-compl

	if(mism_ind < half_word){
		all_mism[0][0] = atemp_seed[0];
		all_mism[1][0] = atemp_seed[1];
		all_mism[0][1] = ta_seed[1];
		all_mism[1][1] = ta_seed[1];
	}
	else{
		all_mism[0][1] = atemp_seed[0];
		all_mism[1][1] = atemp_seed[1];
		all_mism[0][0] = ta_seed[0];
		all_mism[1][0] = ta_seed[0];
	}
}//get_all_backtrace long

void Anchor::get_all_backtrace(const _uli &ta_mism, vector<_uli> &all_mism, _uli mism_ind, bool forward, int &num_mism )
{
	//all_mism is alread resized of size 3
	//
	_uli zero = 0, one = 1, two = 2, three = 3;
	_uli shift_bits = mism_ind << 1;
	_uli ch = (ta_mism >> (shift_bits)) & mask[2];
	_uli amask = ~(three << (shift_bits)); 
	if((forward == true && A_rich == false) || (forward == false && A_rich == true)){
		switch(ch){
			case 0: 
				all_mism[0] = (ta_mism & amask) | (two << (shift_bits)) ; 
				all_mism[1] = (ta_mism & amask) | (three << (shift_bits)) ;
				num_mism = 2;
				break;
			case 2: 
				all_mism[0] = (ta_mism & amask) | (zero << (shift_bits)) ;
				all_mism[1] = (ta_mism & amask) | (three << (shift_bits)) ;
				num_mism = 2;
				break;
			case 3:
				all_mism[0] = (ta_mism & amask) | (zero << (shift_bits)) ; 
				all_mism[1] = (ta_mism & amask) | (two << (shift_bits)) ;
				num_mism = 2;
				break;
			default: num_mism = 0; break;
		}//switch
	}//forward
	else{
		switch(ch){
			case 0: 
				all_mism[0] = (ta_mism & amask) | (one << (shift_bits)) ; 
				all_mism[1] = (ta_mism & amask) | (three << (shift_bits)) ;
				num_mism = 2;
				break;
			case 1: 
				all_mism[0] = (ta_mism & amask) | (zero << (shift_bits)) ; 
				all_mism[1] = (ta_mism & amask) | (three << (shift_bits)) ;
				num_mism = 2;
				break;
			case 3:
				all_mism[0] = (ta_mism & amask) | (zero << (shift_bits)) ; 
				all_mism[1] = (ta_mism & amask) | (one << (shift_bits)) ;
				num_mism = 2;
				break;
			default: num_mism = 0; break;
		}//switch	
	
	}//rev-compl
}//get_all_backtrace

/*
get_all_backtrace: too many
	switch(ch){
		case 0: 
			all_mism[0] = (ta_mism & amask) | (one << (shift_bits)) ; 
			all_mism[1] = (ta_mism & amask) | (two << (shift_bits)) ;
			all_mism[2] = (ta_mism & amask) | (three << (shift_bits)) ;
			break;
		case 1: 
			all_mism[0] = (ta_mism & amask) | (zero << (shift_bits)) ; 
			all_mism[1] = (ta_mism & amask) | (two << (shift_bits)) ;
			all_mism[2] = (ta_mism & amask) | (three << (shift_bits)) ;
			break;
		case 2: 
			all_mism[0] = (ta_mism & amask) | (zero << (shift_bits)) ; 
			all_mism[1] = (ta_mism & amask) | (one << (shift_bits)) ;
			all_mism[2] = (ta_mism & amask) | (three << (shift_bits)) ;
			break;
		case 3:
			all_mism[0] = (ta_mism & amask) | (zero << (shift_bits)) ; 
			all_mism[1] = (ta_mism & amask) | (one << (shift_bits)) ;
			all_mism[2] = (ta_mism & amask) | (two << (shift_bits)) ;
			break;
		default: break;
	}//switch
void Anchor::align_mism_short(const _uli &ta, const _uli &read_len, _uli &sp, _uli &ep, _uli &remainder, 
		const bool &forward, vector< pair< pair<_ui, _ui>, pair<_ui, _ui> > > &sp_ep_remainder,
		const vector<_uli> &all_mism )
{
	//ta here is 2-bit read, all_mism contain 3-substitutions per char, read_len is in bases
	int asize = all_mism.size();
	sp_ep_remainder.resize(asize);

	_uli total_mism = read_len - half_SEED;
	_uli mism_ind = 0;
	_ui three = 3;
	_ui count = 0;
	_ui abase_ind = 0;
	for(_ui i = 0; i < asize; i++){//= because there are one exact ta_mism + total_mism of ta_mism with 1mism
		sp = 0; ep = 0;
		_uli ta_seed = all_mism[i] & mask[SEED];
		_uli ta_rest = (all_mism[i] >> SEED);
		retreive_seed(ta_seed, sp, ep);
		remainder = total_mism;
		exact_match(ta_rest, sp, ep, total_mism, remainder);
		if(sp <= ep){
			sp_ep_remainder[mism_ind] = (make_pair(make_pair(sp, ep), make_pair(remainder, abase_ind)));
			mism_ind++;
		}//if
		count++;
		if(count == three){
			count = 0;
			abase_ind++;
		}
	}//for
	sp_ep_remainder.resize(mism_ind);
		
}//align_mism_short

void Anchor::align_mism(const _uli &ta, const _uli &read_len, _uli &sp, _uli &ep, _uli &remainder, 
		const bool &forward, vector< pair< pair<_ui, _ui> , _ui > > &sp_ep_remainder)
{
	_uli ch = ta & mask[0];
	sp = C[ch];
	ep = C[ch + 1] - 1;
	_uli ta_seed = ta >> 1;
	remainder = read_len - 1;
	exact_match(ta_seed, sp, ep, read_len - 1, remainder);
	if(sp <= ep){
	
		return;
	}//if
	_uli total_mism = read_len - remainder;
	vector<_uli> all_mism(total_mism, 0);
	_uli ta_mism = ta & mask[total_mism];
	get_all_backtrace(ta_mism, total_mism, all_mism);
	sp_ep_remainder.resize(total_mism);
	int res_ind = 0;
	ta_seed = (ta >> total_mism) << total_mism;

	for(_ui i = 0; i < total_mism; i++){
		_uli ta_comb = ta_seed | all_mism[i];
		_uli ta_first = ta_comb & mask[SEED];
		_uli ta_rest = ta_comb >> SEED;
		sp = 0; ep = 0;
		retreive_seed(ta_first, sp, ep);
		remainder = read_len - SEED;//length of ta_rest
		exact_match(ta_rest, sp, ep, read_len - SEED, remainder);
		if(sp <= ep){
			sp_ep_remainder[res_ind] = make_pair(make_pair(sp, ep), remainder);
			res_ind++;
		}
	}//for
	sp_ep_remainder.resize(res_ind);
}//align_mism
*/


void Anchor::map_pos_mism_long(const vector<_uli> &acgt_read, const vector<_uli> &ta_read1, const _uli &read_len1, 
		const vector<_uli> &c_read1, const bool &forward, bool &pair_ambiguous,  Mates &mates_pairs,
		const vector<_uli> &ns_read1, bool mism_map, const Anchor &anc)
{//long BIG SEED > 32
	_uli new_read_len = min(read_len1, anc.BIG_SEED);

	long int asize_ta = acgt_read.size();
	long int asize_seed = ((new_read_len << 1) >> two_in_Size) + ( ((new_read_len << 1) & mask[two_in_Size]) > 0 ? 1 : 0);
	vector<_uli> ta_seed(asize_seed, 0);
	//bases in the last block
	_uli rest_read_len = read_len1 - ((asize_ta - 1) << anc.two_in_32);

	//how many blocks we need to keep ta_seed:
	_uli total_blocks = asize_seed ;//the last 1 holds rest_read_len

	//index of the first block keeping ta_seed
	_uli first_block = asize_ta - total_blocks;
	_uli ta_seed1 = 0, c_seed1 = 0, ns_seed1 = 0;

	if(forward == true){
		_uli rem_unused_bits = ((total_blocks - 1) << two_in_Size) - ((new_read_len - rest_read_len) << 1);
		int seed_ind = 0;
		int y = first_block;
		for(; y < asize_ta - 2; y++){
			ta_seed[seed_ind] = (acgt_read[y] >> rem_unused_bits)| (acgt_read[y + 1] << (SIZE - rem_unused_bits));
			seed_ind++;
		}//for y
		ta_seed[seed_ind] = (acgt_read[y] >> rem_unused_bits) ;
		y++;

		if(rem_unused_bits < (rest_read_len << 1)){
			ta_seed[seed_ind] |= ((acgt_read[y] & mask[rem_unused_bits])) << (SIZE - rem_unused_bits);
			seed_ind++;
			ta_seed[seed_ind] = (acgt_read[y] >> rem_unused_bits);
		}
		else{
			ta_seed[seed_ind] |= acgt_read[y] << (SIZE - rem_unused_bits);
		}
		//1-bit representation

		_uli rest_bits = read_len1 & mask[two_in_Size];
		//rest_bits is the entire length of short ta-read, new_read_len is BIG-SEED or ta-read length
		_uli rest_read_len = rest_bits;
		int ta_size = ta_read1.size();
		if(rest_read_len > new_read_len){
			ta_seed1 = ta_read1[ta_size - 1] >> (rest_read_len - new_read_len);
			c_seed1 = c_read1[ta_size  - 1] >> (rest_read_len - new_read_len);
			ns_seed1 = ns_read1[ta_size  - 1] >> (rest_read_len - new_read_len);
		}
		else{
			ta_seed1 = (ta_read1[ta_size - 1] << (new_read_len - rest_read_len)) | 
				(ta_read1[ta_size - 2] >> (SIZE - (new_read_len - rest_read_len)));
			c_seed1 = (c_read1[ta_size - 1] << (new_read_len - rest_read_len)) | 
				(c_read1[ta_size - 2] >> (SIZE - (new_read_len - rest_read_len)));
			ns_seed1 = (ns_read1[ta_size - 1] << (new_read_len - rest_read_len)) | 
				(ns_read1[ta_size - 2] >> (SIZE - (new_read_len - rest_read_len)));
		}

	}
	else{
		//also assumption is this function gets BIG-SEEDS that are > 32 bases
		_uli rest_bits = SIZE - ((SIZE << 1) - (new_read_len << 1));//assumption is that BIG_SEED is max 62 bases
		ta_seed[0] = acgt_read[0];
		ta_seed[1] = acgt_read[1] & mask[rest_bits];
			ta_seed1 = ta_read1[0] & mask[new_read_len];
			c_seed1 = c_read1[0] & mask[new_read_len];
			ns_seed1 = ns_read1[0] & mask[new_read_len];
	}

			//check which region of ta_seed contains a mism
			_uli sp = 0;
			_uli ep = 0;
			_uli remainder = new_read_len;

			align_linear(ta_seed, sp, ep, new_read_len, remainder, 0);//only first BIG_SEED
			//end check, now remainder points to position where mism is |read_len -1, real_len-2,...,read_len - remainder -1| does not contain mism
			int stop = new_read_len - remainder;
			int num_substitutions = 2;
			vector<_uli> atemp(asize_seed, 0);
			vector< vector<_uli> > all_mism(num_substitutions, atemp);//2 substitutions for each base

			Mates mates_seeds;

			for(int y = 0; y < stop; y++){

				get_all_backtrace(ta_seed, all_mism, y, forward, num_substitutions);
				for(int u = 0; u < num_substitutions; u++){
					sp = 0;
					ep = 0;
					_uli remainder = new_read_len;
					align_linear_seed(all_mism[u], sp, ep, new_read_len, remainder, 0);//only first BIG_SEED
					if(sp == ep){
//						if(forward == false)
//							remainder += (read_len1 - new_read_len);//don't need to do this for a seed
						//no need to align to genome again
		
						if(allow_C_to_T == 0){
							map_pos(sp, ep, ta_seed1, new_read_len, c_seed1, 
								forward, pair_ambiguous, remainder, mates_seeds, ns_seed1, true, anc);
						}
						else{
							_ui pos1 = find_gen_pos(sp, remainder);
							char strand = '+';
							if(forward == false)
								strand = '-';
							update_singles(mates_seeds, strand, pos1, 1, pair_ambiguous, mism_map);							
						}
					}//if
					else if(sp < ep){
						if(allow_C_to_T == 1){
							pair_ambiguous = true;
							if(read_len1 == new_read_len){
								mates_pairs.mark_unique = 2;
								mates_pairs.mism1 = 1;
							}
							return;
						}
						else{
							map_pos(sp, ep, ta_seed1, new_read_len, c_seed1, 
								forward, pair_ambiguous, remainder, mates_seeds, ns_seed1, true, anc);						
						}//dont allow C to T
					}//else sp < ep
					if(pair_ambiguous == true ){//0 or 1mism
						if(read_len1 == new_read_len){
							mates_pairs.mark_unique = 2;
							mates_pairs.mism1 = 1;
						}
						return;
					}
				}//for 3 substitutions
			}//for y
			if(mates_seeds.mark_unique == 1){
				//mapped seed uniquely
				char strand = '+';
				remainder = 0;
				if(forward == false){
					remainder = read_len1 - new_read_len;
					strand = '-';
				}
				vector<_uli> ta_check(asize_ta, 0);
				bool cg_mism1 = false;

				_uli pos1 = mates_seeds.pos1 - remainder;
				int mism1 = cg_match(read_len1, pos1, ta_read1, c_read1, ta_check, forward, 
					cg_mism1, ns_read1, anc);
				if(mism1 <= mism_thresh)
					ta_match(read_len1, pos1, ta_read1, ta_check, ns_read1, mism1, anc);
				if(mism1 <= mism_thresh)
					update_singles(mates_pairs, strand, mates_seeds.pos1 - remainder, mism1, pair_ambiguous, mism_map);	
			}//if seed mapped uniquely
}//map_pos_mism_long long ta-repres

void Anchor::map_pos_mism_long(const vector<_uli> &acgt_read, const _uli &ta_read1, const _uli &read_len1, const _uli &c_read1, 
		const bool &forward, bool &pair_ambiguous,  Mates &mates_pairs,
		const _uli &ns_read1, bool mism_map, const Anchor &anc)
{
	_uli new_read_len = min(read_len1, anc.BIG_SEED);

	long int asize_ta = acgt_read.size();
	long int asize_seed = ((new_read_len << 1) >> two_in_Size) + ( ((new_read_len << 1) & mask[two_in_Size]) > 0 ? 1 : 0);
	vector<_uli> ta_seed(asize_seed, 0);
	//bases in the last block
	_uli rest_read_len = read_len1 - ((asize_ta - 1) << anc.two_in_32);

	//how many blocks we need to keep ta_seed:
	_uli total_blocks = asize_seed ;//the last 1 holds rest_read_len

	//index of the first block keeping ta_seed
	_uli first_block = asize_ta - total_blocks;
	_uli ta_seed1 = 0, c_seed1 = 0, ns_seed1 = 0;

	if(forward == true){
		_uli rem_unused_bits = ((total_blocks - 1) << two_in_Size) - ((new_read_len - rest_read_len) << 1);
		int seed_ind = 0;
		int y = first_block;
		for(; y < asize_ta - 2; y++){
			ta_seed[seed_ind] = (acgt_read[y] >> rem_unused_bits)| (acgt_read[y + 1] << (SIZE - rem_unused_bits));
			seed_ind++;
		}//for y
		ta_seed[seed_ind] = (acgt_read[y] >> rem_unused_bits) ;
		y++;
		if(rem_unused_bits < (rest_read_len << 1)){
			ta_seed[seed_ind] |= ((acgt_read[y] & mask[rem_unused_bits])) << (SIZE - rem_unused_bits);
			seed_ind++;
			ta_seed[seed_ind] = (acgt_read[y] >> rem_unused_bits);
		}
		else{
			ta_seed[seed_ind] |= acgt_read[y] << (SIZE - rem_unused_bits);
		}
		//1-bit representation


		//rest_bits is the entire length of short ta-read, new_read_len is BIG-SEED or ta-read length
			ta_seed1 = ta_read1 >> (read_len1 - new_read_len);
			c_seed1 = c_read1 >> (read_len1 - new_read_len);
			ns_seed1 = ns_read1 >> (read_len1 - new_read_len);

	}
	else{
		//also assumption is this function gets BIG-SEEDS that are > 32 bases
		_uli rest_bits = SIZE - ((SIZE << 1) - (new_read_len << 1));//assumption is that BIG_SEED is max 62 bases
		ta_seed[0] = acgt_read[0];
		ta_seed[1] = acgt_read[1] & mask[rest_bits];
			ta_seed1 = ta_read1 & mask[new_read_len];
			c_seed1 = c_read1 & mask[new_read_len];
			ns_seed1 = ns_read1 & mask[new_read_len];
	}

			//check which region of ta_seed contains a mism
			_uli sp = 0;
			_uli ep = 0;
			_uli remainder = new_read_len;

			align_linear(ta_seed, sp, ep, new_read_len, remainder, 0);//only first BIG_SEED
			//end check, now remainder points to position where mism is |read_len -1, real_len-2,...,read_len - remainder -1| does not contain mism
			int stop = new_read_len - remainder;
			int num_substitutions = 2;
			vector<_uli> atemp(asize_seed, 0);
			vector< vector<_uli> > all_mism(num_substitutions, atemp);//2 substitutions for each base

			Mates mates_seeds;

			for(int y = 0; y < stop; y++){

				get_all_backtrace(ta_seed, all_mism, y, forward, num_substitutions);
				for(int u = 0; u < num_substitutions; u++){
					sp = 0;
					ep = 0;
					_uli remainder = new_read_len;
					align_linear_seed(all_mism[u], sp, ep, new_read_len, remainder, 0);//only first BIG_SEED
					if(sp == ep){
//						if(forward == false)
//							remainder += (read_len1 - new_read_len);//don't need to do this for a seed
						//no need to align to genome again
		
						if(allow_C_to_T == 0){
							map_pos(sp, ep, ta_seed1, new_read_len, c_seed1, 
								forward, pair_ambiguous, remainder, mates_seeds, ns_seed1, true, anc);
						}
						else{
							_ui pos1 = find_gen_pos(sp, remainder);
							char strand = '+';
							if(forward == false)
								strand = '-';
							update_singles(mates_seeds, strand, pos1, 1, pair_ambiguous, mism_map);							
						}
					}//if
					else if(sp < ep){
						if(allow_C_to_T == 1){
							pair_ambiguous = true;
							if(read_len1 == new_read_len){
								mates_pairs.mark_unique = 2;
								mates_pairs.mism1 = 1;
							}
							return;
						}
						else{
							map_pos(sp, ep, ta_seed1, new_read_len, c_seed1, 
								forward, pair_ambiguous, remainder, mates_seeds, ns_seed1, true, anc);						
						}//dont allow C to T
					}//else sp < ep
					if(pair_ambiguous == true ){//0 or 1mism
						if(read_len1 == new_read_len){
							mates_pairs.mark_unique = 2;
							mates_pairs.mism1 = 1;
						}
						return;
					}
				}//for 3 substitutions
			}//for y
			if(mates_seeds.mark_unique == 1){
				//mapped seed uniquely
				char strand = '+';
				remainder = 0;
				if(forward == false){
					remainder = read_len1 - new_read_len;
					strand = '-';
				}
				_uli ta_check = 0;
				bool cg_mism1 = false;
				int mism1 = cg_match(read_len1, mates_seeds.pos1 - remainder, ta_read1, c_read1, ta_check, forward, cg_mism1, ns_read1, anc);
				if(mism1 <= mism_thresh)
					ta_match(read_len1, mates_seeds.pos1 - remainder, ta_read1, ta_check, ns_read1, mism1, anc);
				if(mism1 <= mism_thresh)
					update_singles(mates_pairs, strand, mates_seeds.pos1 - remainder, mism1, pair_ambiguous, mism_map);	
			}//if seed mapped uniquely

}//map_pos_mism_long

void Anchor::map_pos_mism(const vector<_uli> &acgt_read, const vector<_uli> &ta_read1, const _uli &read_len1, 
		const vector<_uli> &c_read1, const bool &forward, bool &pair_ambiguous,  Mates &mates_pairs,
		const vector<_uli> &ns_read1, bool mism_map, const Anchor &anc)
{//short BIG SEED = 32 and ta-repres > 64
	_uli new_read_len = min(read_len1, anc.BIG_SEED);

	_uli ta_seed = 0;
	_uli ta_seed1 = 0, c_seed1 = 0, ns_seed1 = 0;
	
	long int asize_ta = acgt_read.size();
	if(forward == true){
		_uli rest_read_len = read_len1 - ((asize_ta - 1) << anc.two_in_32);
				if(rest_read_len >= new_read_len){
					ta_seed = acgt_read[asize_ta - 1] >> ((rest_read_len - new_read_len) << 1);
				}
				else{
					ta_seed = (acgt_read[asize_ta - 1] << ((new_read_len - rest_read_len) << 1)) | 
						(acgt_read[asize_ta - 2] >> (anc.SIZE - ((new_read_len - rest_read_len) << 1)));
				}
			_uli rest_bits = read_len1 & mask[two_in_Size];//for ta/cg-1bit-representation
			//rest_bits is the entire length of short ta-read, new_read_len is BIG-SEED or ta-read length
			rest_read_len = rest_bits;
			int ta_size = ta_read1.size();
			if(rest_read_len > new_read_len){

				ta_seed1 = ta_read1[ta_size - 1] >> (rest_read_len - new_read_len);
				c_seed1 = c_read1[ta_size  - 1] >> (rest_read_len - new_read_len);
				ns_seed1 = ns_read1[ta_size  - 1] >> (rest_read_len - new_read_len);
			}
			else{
				ta_seed1 = (ta_read1[ta_size - 1] << (new_read_len - rest_read_len)) | 
					(ta_read1[ta_size - 2] >> (SIZE - (new_read_len - rest_read_len)));
				c_seed1 = (c_read1[ta_size - 1] << (new_read_len - rest_read_len)) | 
					(c_read1[asize_ta - 2] >> (SIZE - (new_read_len - rest_read_len)));
				ns_seed1 = (ns_read1[ta_size - 1] << (new_read_len - rest_read_len)) | 
					(ns_read1[ta_size - 2] >> (SIZE - (new_read_len - rest_read_len)));
			}

		}
		else{
				ta_seed = acgt_read[0] & mask[new_read_len << 1];
				ta_seed1 = ta_read1[0] & mask[new_read_len];
				c_seed1 = c_read1[0] & mask[new_read_len];
				ns_seed1 = ns_read1[0] & mask[new_read_len];
			}

			//check which region of ta_seed contains a mism
			_uli sp = 0;
			_uli ep = 0;
			_uli remainder = new_read_len;
			align_linear(ta_seed, sp, ep, new_read_len, remainder);//only first BIG_SEED
			//end check, now remainder points to position where mism is |read_len -1, real_len-2,...,read_len - remainder -1| does not contain mism
			int stop = new_read_len - remainder;
			int num_substitutions = 2;
			vector<_uli> all_mism(num_substitutions, 0);//3 substitutions for each base
			Mates mates_seeds;

			for(int y = 0; y < stop; y++){

				get_all_backtrace(ta_seed, all_mism, y, forward, num_substitutions);
				for(int u = 0; u < num_substitutions; u++){
					sp = 0;
					ep = 0;
					_uli remainder = new_read_len;
					//here align_linear aligns entire seed
					align_linear(all_mism[u], sp, ep, new_read_len, remainder);//only first BIG_SEED
					if(sp == ep){
//						if(forward == false)
//							remainder += (read_len1 - new_read_len);//don't need to do this for a seed
						//no need to align to genome again
		
						if(allow_C_to_T == 0){
							map_pos(sp, ep, ta_seed1, new_read_len, c_seed1, 
								forward, pair_ambiguous, remainder, mates_seeds, ns_seed1, true, anc);
						}
						else{
							_ui pos1 = find_gen_pos(sp, remainder);
							char strand = '+';
							if(forward == false)
								strand = '-';
							update_singles(mates_seeds, strand, pos1, 1, pair_ambiguous, true);	//we introduced 1 mism						
						}
					}//if
					else if(sp < ep){
						if(allow_C_to_T == 1){
							pair_ambiguous = true;
							if(read_len1 == new_read_len){
								mates_pairs.mark_unique = 2;
								mates_pairs.mism1 = 1;
							}
							return;
						}
						else{
							map_pos(sp, ep, ta_seed1, new_read_len, c_seed1, 
								forward, pair_ambiguous, remainder, mates_seeds, ns_seed1, true, anc);						
						}//dont allow C to T
					}//else sp < ep
					if(pair_ambiguous == true ){//1mism ambiguous in seed
						if(read_len1 == new_read_len){
							mates_pairs.mark_unique = 2;
							mates_pairs.mism1 = 1;
						}
						return;
					}
				}//for 3 substitutions
			}//for y
			if(mates_seeds.mark_unique == 1){
				//mapped seed uniquely
				char strand = '+';
				remainder = 0;
				if(forward == false){
					remainder = read_len1 - new_read_len;
					strand = '-';
				}
				vector<_uli> ta_check(asize_ta, 0);
				bool cg_mism1 = false;
				int mism1 = cg_match(read_len1, mates_seeds.pos1 - remainder, ta_read1, c_read1, ta_check, forward, 
					cg_mism1, ns_read1, anc);
				if(mism1 <= mism_thresh)
					ta_match(read_len1, mates_seeds.pos1 - remainder, ta_read1, ta_check, ns_read1, mism1, anc);
				if(mism1 <= mism_thresh)
					update_singles(mates_pairs, strand, mates_seeds.pos1 - remainder, mism1, pair_ambiguous, true);	
			}//if seed mapped uniquely
}//map_pos_mism long ta-repres

void Anchor::map_pos_mism(const vector<_uli> &acgt_read, const _uli &ta_read1, const _uli &read_len1, const _uli &c_read1, 
		const bool &forward, bool &pair_ambiguous,  Mates &mates_pairs,
		const _uli &ns_read1, bool mism_map, const Anchor &anc)
{//short BIG SEED = 32 and ta-repres = 32..64
	_uli new_read_len = min(read_len1, anc.BIG_SEED);

			_uli ta_seed = 0;
	_uli ta_seed1 = 0, c_seed1 = 0, ns_seed1 = 0;
	
			long int asize_ta = acgt_read.size();
			if(forward == true){
				_uli rest_read_len = read_len1 - ((asize_ta - 1) << anc.two_in_32);
				if(rest_read_len >= new_read_len){
					ta_seed = acgt_read[asize_ta - 1] >> ((rest_read_len - new_read_len) << 1);
				}
				else{
					ta_seed = (acgt_read[asize_ta - 1] << ((new_read_len - rest_read_len) << 1)) | 
						(acgt_read[asize_ta - 2] >> (anc.SIZE - ((new_read_len - rest_read_len) << 1)));
				}
			
			//rest_bits is the entire length of short ta-read, new_read_len is BIG-SEED or ta-read length
			ta_seed1 = ta_read1 >> (read_len1 - new_read_len);
			c_seed1 = c_read1 >> (read_len1 - new_read_len);
			ns_seed1 = ns_read1 >> (read_len1 - new_read_len);		

			}
			else{
				ta_seed = acgt_read[0] & mask[new_read_len << 1];
				ta_seed1 = ta_read1 & mask[new_read_len];
				c_seed1 = c_read1 & mask[new_read_len];
				ns_seed1 = ns_read1 & mask[new_read_len];
			}

			//check which region of ta_seed contains a mism
			_uli sp = 0;
			_uli ep = 0;
			_uli remainder = new_read_len;
			align_linear(ta_seed, sp, ep, new_read_len, remainder);//only first BIG_SEED
			//end check, now remainder points to position where mism is |read_len -1, real_len-2,...,read_len - remainder -1| does not contain mism
			int stop = new_read_len - remainder;
			int num_substitutions = 2;
			vector<_uli> all_mism(num_substitutions, 0);//3 substitutions for each base
			Mates mates_seeds;

			for(int y = 0; y < stop; y++){

				get_all_backtrace(ta_seed, all_mism, y, forward, num_substitutions);
				for(int u = 0; u < num_substitutions; u++){
					sp = 0;
					ep = 0;
					_uli remainder = new_read_len;
					
					align_linear(all_mism[u], sp, ep, new_read_len, remainder);//only first BIG_SEED
					if(sp == ep){
//						if(forward == false)
//							remainder += (read_len1 - new_read_len);//don't need to do this for a seed
						//no need to align to genome again
		
						if(allow_C_to_T == 0){
							map_pos(sp, ep, ta_seed1, new_read_len, c_seed1, 
								forward, pair_ambiguous, remainder, mates_seeds, ns_seed1, true, anc);
						}
						else{
							_ui pos1 = find_gen_pos(sp, remainder);
							char strand = '+';
							if(forward == false)
								strand = '-';
							update_singles(mates_seeds, strand, pos1, 1, pair_ambiguous, mism_map);							
						}
					}//if
					else if(sp < ep){
						if(allow_C_to_T == 1){
							pair_ambiguous = true;
							if(read_len1 == new_read_len){
								mates_pairs.mark_unique = 2;
								mates_pairs.mism1 = 1;
							}
							return;
						}
						else{
							map_pos(sp, ep, ta_seed1, new_read_len, c_seed1, 
								forward, pair_ambiguous, remainder, mates_seeds, ns_seed1, true, anc);						
						}//dont allow C to T
					}//else sp < ep
					if(pair_ambiguous == true ){//0 or 1mism
						if(read_len1 == new_read_len){
							mates_pairs.mark_unique = 2;
							mates_pairs.mism1 = 1;
						}
						return;
					}
				}//for 3 substitutions
			}//for y
			if(mates_seeds.mark_unique == 1){
				//mapped seed uniquely
				char strand = '+';
				remainder = 0;
				if(forward == false){
					remainder = read_len1 - new_read_len;
					strand = '-';
				}
				_uli ta_check = 0;
				bool cg_mism1 = false;
				int mism1 = cg_match(read_len1, mates_seeds.pos1 - remainder, ta_read1, c_read1, ta_check, forward, cg_mism1, ns_read1, anc);
				if(mism1 <= mism_thresh)
					ta_match(read_len1, mates_seeds.pos1 - remainder, ta_read1, ta_check, ns_read1, mism1, anc);
				if(mism1 <= mism_thresh)
					update_singles(mates_pairs, strand, mates_seeds.pos1 - remainder, mism1, pair_ambiguous, mism_map);	
			}//if seed mapped uniquely
			
}//map_pos_mism

void pair_reads_singles(_uli read_id, string aread1,
				Stat &astat, _uli read_len1, _uli st1, _uli en1, Mates &mates_pairs, Anchor &anc_ct, Anchor &anc_ga )
{
	//read_len1 is given in bases
	anc_ct.init_params(read_len1);
	anc_ga.init_params(read_len1);

	unsigned long int one = 1, mism1, ta_lmer1, cg_lmer1;
	unsigned long int asize,   pos1, dist, i;
	char strand;
	unsigned long int MASK_READ1 = ( one << read_len1) - 1;
	if(read_len1 > 31){
		dist = read_len1 - 32;
		MASK_READ1 = (((one << dist) - 1) << 32) | 0x00000000FFFFFFFF;
	}
	unsigned long int ta_rc1=0,  ind1 = 0;//hash-indices 
	unsigned long int  c_read1 = 0;
	unsigned long int  ta_read1 = 0,  ns_read1=0;
	unsigned long int ta_gen_mer1 = 0, cg_gen_mer1 = 0;
	unsigned long int start1, end1;
	bool pair_ambiguous = false;

	vector<_uli> acgt_read, acgt_rc_read;
	//get ta-read, cg-read, ns-read
	long int num_ns = anc_ct.convert_lmer_ta_cg(aread1, ta_read1, c_read1, ns_read1, acgt_read,
		acgt_rc_read, read_len1, mates_pairs);
	if(num_ns > anc_ct.mism_thresh)
		return;

	_uli ta_read2 = 0, c_read2 = 0, ns_read2 = 0;
		vector<_uli> acgt_read2, acgt_rc_read2;

	num_ns = anc_ga.convert_lmer_ta_cg(aread1, ta_read2, c_read2, ns_read2, acgt_read2,
		acgt_rc_read2, read_len1, mates_pairs);

	//try to match read exactly (fully or partially)
	_uli sp = 0, ep = 0; //retreive_seed shifts these values: have to be 0	
	_uli min_shift = (read_len1 - anc_ct.SEED) << 1;
	if(read_len1 >= anc_ct.MIN_READ)
		min_shift = (read_len1 - anc_ct.MIN_READ) << 1;//2bit repres
	_uli cur_shift_delta = min(anc_ct.shift_delta, min_shift);//num_shifts calculated from this

	_uli anew_read_len = read_len1 - anc_ct.SEED;
	if(anc_ct.MIN_READ <= read_len1)
		anew_read_len = read_len1 - anc_ct.MIN_READ;//was SEED, but we don't want short reads < 48
	//two_in_shift_delta is in bases
	_uli num_shifts = min((anew_read_len >> anc_ct.two_in_shift_delta) + 1, anc_ct.max_num_shifts);
	

		//try to match read exactly (fully or partially)

	_uli total_bits = 0;
	  for(_uli y = 0; y < num_shifts; y++){
		_uli remainder = read_len1;
		if(anc_ct.A_rich == false)
			anc_ct.align_linear(acgt_read, sp, ep, read_len1, remainder, total_bits);//only ta-alignment
		else
			anc_ga.align_linear(acgt_read2, sp, ep, read_len1, remainder, total_bits);//only ta-alignment

		if(sp <= ep){//mapped exactly
			//process forward read1 
			//start and end of list of genome positions for forw1
			bool forward = true;
		if(anc_ct.A_rich == false){
			anc_ct.map_pos(sp, ep, ta_read1, read_len1, c_read1, 
				forward, pair_ambiguous, remainder, mates_pairs, ns_read1, false, anc_ct);
		}
		else{
			anc_ga.map_pos(sp, ep, ta_read2, read_len1, c_read2, 
				forward, pair_ambiguous, remainder, mates_pairs, ns_read2, false, anc_ct);		
		}
	
		}//if mapped exactly to forward strand
		if(pair_ambiguous == true && mates_pairs.mism1 == 0)
			return;
	
		total_bits += cur_shift_delta ;
		if(total_bits > ((read_len1 - anc_ct.MIN_READ ) << 1))
			break;
	  }//for y

	  //AG-representation exact mapping
	//Map reverse-complement of the read to forward strand
	//take rev-complement of the first read

	_uli ta_rc_read2 = MASK_READ1 & (~Reverse(ta_read2, read_len1));
	_uli c_rc_read2 =  Reverse(c_read2, read_len1);//shows positions of Gs in reverse strand	
	_uli ns_rc_read2 = Reverse(ns_read2, read_len1);
		//try to match read exactly (fully or partially)
	_uli ta_rc_read1 = MASK_READ1 & (~Reverse(ta_read1, read_len1));
	_uli c_rc_read1 =  Reverse(c_read1, read_len1);//shows positions of Gs in reverse strand	
	_uli ns_rc_read1 = Reverse(ns_read1, read_len1);

	total_bits = 0;
	  for(_uli y = 0; y < num_shifts; y++){
		_uli sp = 0, ep = 0; //retreive_seed shifts these values: have to be 0	
		
		_uli remainder = read_len1;
		if(anc_ct.A_rich == false)
			anc_ga.align_linear(acgt_rc_read2, sp, ep, read_len1,  remainder, total_bits);//only ta-alignment
		else
			anc_ct.align_linear(acgt_rc_read, sp, ep, read_len1,  remainder, total_bits);//only ta-alignment

		if(sp <= ep){//mapped exactly
				//process forward read1 
				//start and end of list of genome positions for forw1
			bool forward = false;
			if(anc_ct.A_rich == false){
				anc_ga.map_pos(sp, ep, ta_rc_read2, read_len1, c_rc_read2, 
					forward, pair_ambiguous, remainder, mates_pairs, ns_rc_read2, false, anc_ct);
			}
			else{
				anc_ct.map_pos(sp, ep, ta_rc_read1, read_len1, c_rc_read1, 
					forward, pair_ambiguous, remainder, mates_pairs, ns_rc_read1, false, anc_ct);			
			}
	
		}//if mapped exactly to forward strand
		if(pair_ambiguous == true && mates_pairs.mism1 == 0)
				return;

		total_bits += cur_shift_delta;
		if(total_bits > ((read_len1 - anc_ct.MIN_READ ) << 1))
			break;
	}//for y
	//if by now did not map exactly, then there is at least 1 mism with 1mism being the best number of mism, hense this condition
	  if(pair_ambiguous == true && mates_pairs.mism1 == 1)
		  return;//if it did not map exactly, there must be at least 1 mism, and 1mism is the best number of mism


	  ///////////////////////////exact BIG seed
	 if(read_len1 > anc_ct.BIG_SEED){
		bool forward = true;
	//align exact-match for BIG-SEED: this decreases chance of missing ambiguous in addition to mapping
	  if(anc_ct.BIG_SEED > anc_ct.half_word){


		_uli new_read_len = min(read_len1, anc_ct.BIG_SEED);

		long int asize_ta = acgt_read.size();
		long int asize_seed = ((new_read_len << 1) >> anc_ct.two_in_Size) + ( ((new_read_len << 1) & anc_ct.mask[anc_ct.two_in_Size]) > 0 ? 1 : 0);
		vector<_uli> ta_seed(asize_seed, 0);
		//bases in the last block
		_uli rest_read_len = read_len1 - ((asize_ta - 1) << anc_ct.two_in_32);

		//how many blocks we need to keep ta_seed:
		_uli total_blocks = asize_seed ;//the last 1 holds rest_read_len

		//index of the first block keeping ta_seed
		_uli first_block = asize_ta - total_blocks;

		_uli rem_unused_bits = ((total_blocks - 1) << anc_ct.two_in_Size) - ((new_read_len - rest_read_len) << 1);
		int seed_ind = 0;
		int y = first_block;
		if(anc_ct.A_rich == false){
			for(; y < asize_ta - 2; y++){
				ta_seed[seed_ind] = (acgt_read[y] >> rem_unused_bits)| (acgt_read[y + 1] << (anc_ct.SIZE - rem_unused_bits));
				seed_ind++;
			}//for y
			ta_seed[seed_ind] = (acgt_read[y] >> rem_unused_bits) ;
			y++;
			if(rem_unused_bits < (rest_read_len << 1)){
				ta_seed[seed_ind] |= ((acgt_read[y] & anc_ct.mask[rem_unused_bits])) << (anc_ct.SIZE - rem_unused_bits);
				seed_ind++;
				ta_seed[seed_ind] = (acgt_read[y] >> rem_unused_bits);
			}
			else{
				ta_seed[seed_ind] |= acgt_read[y] << (anc_ct.SIZE - rem_unused_bits);
			}
		}//if A is false
		else{
			for(; y < asize_ta - 2; y++){
				ta_seed[seed_ind] = (acgt_read2[y] >> rem_unused_bits)| (acgt_read2[y + 1] << (anc_ct.SIZE - rem_unused_bits));
				seed_ind++;
			}//for y
			ta_seed[seed_ind] = (acgt_read2[y] >> rem_unused_bits) ;
			y++;
			if(rem_unused_bits < (rest_read_len << 1)){
				ta_seed[seed_ind] |= ((acgt_read2[y] & anc_ct.mask[rem_unused_bits])) << (anc_ct.SIZE - rem_unused_bits);
				seed_ind++;
				ta_seed[seed_ind] = (acgt_read2[y] >> rem_unused_bits);
			}
			else{
				ta_seed[seed_ind] |= acgt_read2[y] << (anc_ct.SIZE - rem_unused_bits);
			}		
		}//A is true


		//1-bit representation

			_uli remainder = new_read_len;

			sp = 0; ep = 0;

			if(anc_ct.A_rich == false)
				anc_ct.align_linear_seed(ta_seed, sp, ep, new_read_len, remainder, 0);//only first BIG_SEED
			else 
				anc_ga.align_linear_seed(ta_seed, sp, ep, new_read_len, remainder, 0);//only first BIG_SEED

			if(sp <= ep){
				if(anc_ct.A_rich == false){
					anc_ct.map_pos(sp, ep, ta_read1, read_len1, c_read1, 
						forward, pair_ambiguous, remainder, mates_pairs, ns_read1, true, anc_ct);
				}
				else{
					anc_ga.map_pos(sp, ep, ta_read2, read_len1, c_read2, 
						forward, pair_ambiguous, remainder, mates_pairs, ns_read2, true, anc_ct);				
				}
			}//if
		}//if BIG_SEED > 32
		else{
			_uli new_read_len = min(anc_ct.BIG_SEED, read_len1);
			_uli remainder = new_read_len;

			sp = 0; ep = 0;
			_uli ta_seed = 0;

			long int asize_ta = acgt_read.size();
			_uli rest_read_len = read_len1 - ((asize_ta - 1) << anc_ct.two_in_32);
			if(anc_ct.A_rich == false){

				if(rest_read_len >= new_read_len){
					ta_seed = acgt_read[asize_ta - 1] >> ((rest_read_len - new_read_len) << 1);
				}
				else{
					ta_seed = (acgt_read[asize_ta - 1] << ((new_read_len - rest_read_len) << 1)) | 
						(acgt_read[asize_ta - 2] >> (anc_ct.SIZE - ((new_read_len - rest_read_len) << 1)));
					}
			}//A false
			else{
				if(rest_read_len >= new_read_len){
					ta_seed = acgt_read2[asize_ta - 1] >> ((rest_read_len - new_read_len) << 1);
				}
				else{
					ta_seed = (acgt_read2[asize_ta - 1] << ((new_read_len - rest_read_len) << 1)) | 
						(acgt_read2[asize_ta - 2] >> (anc_ct.SIZE - ((new_read_len - rest_read_len) << 1)));
					}			
			}//A true

			if(anc_ct.A_rich == false)
				anc_ct.align_linear(ta_seed, sp, ep, new_read_len, remainder);//only first BIG_SEED
			else
				anc_ga.align_linear(ta_seed, sp, ep, new_read_len, remainder);//only first BIG_SEED

			if(sp <= ep){
				if(anc_ct.A_rich == false){
					anc_ct.map_pos(sp, ep, ta_read1, read_len1, c_read1, 
						forward, pair_ambiguous, remainder, mates_pairs, ns_read1, true, anc_ct);
				}
				else{
					anc_ga.map_pos(sp, ep, ta_read2, read_len1, c_read2, 
						forward, pair_ambiguous, remainder, mates_pairs, ns_read2, true, anc_ct);				
				}
			}//if
		
		}//else if BIG SEED = 32

		if(pair_ambiguous == true && mates_pairs.mism1 == 0)
			return;
 
	  }//if read_len > BIG_SEED
	  //if mapped exactly, then this condition is not true
	  if(pair_ambiguous == true && mates_pairs.mism1 == 1)
		  return;//if it did not map exactly, there must be at least 1 mism, and 1mism is the best number of mism

	  	  /////////////exact BIG seed for rev-comple AG-representation
	  if(read_len1 > anc_ga.BIG_SEED){
		bool forward = false;	
		if(anc_ga.BIG_SEED > anc_ga.half_word){

		_uli new_read_len = min(read_len1, anc_ct.BIG_SEED);

		long int asize_ta = acgt_rc_read2.size();
		long int asize_seed = ((new_read_len << 1) >> anc_ct.two_in_Size) + ( ((new_read_len << 1) & anc_ct.mask[anc_ct.two_in_Size]) > 0 ? 1 : 0);
		vector<_uli> ta_seed(asize_seed, 0);
		//bases in the last block
		//how many blocks we need to keep ta_seed:
		_uli total_blocks = asize_seed ;//the last 1 holds rest_read_len
		//index of the first block keeping ta_seed
		_uli first_block = asize_ta - total_blocks;

			//also assumption is this function gets BIG-SEEDS that are > 32 bases
			_uli rest_bits = anc_ct.SIZE - ((anc_ct.SIZE << 1) - (new_read_len << 1));//assumption is that BIG_SEED is max 62 bases
			if(anc_ct.A_rich == false){
				ta_seed[0] = acgt_rc_read2[0];
				ta_seed[1] = acgt_rc_read2[1] & anc_ct.mask[rest_bits];
			}//A false
			else{
				ta_seed[0] = acgt_rc_read[0];
				ta_seed[1] = acgt_rc_read[1] & anc_ct.mask[rest_bits];			
			}//A true

			_uli remainder = new_read_len;
			if(anc_ct.A_rich == false)
				anc_ga.align_linear_seed(ta_seed, sp, ep, new_read_len, remainder, 0);//only first BIG_SEED
			else
				anc_ct.align_linear_seed(ta_seed, sp, ep, new_read_len, remainder, 0);//only first BIG_SEED

			if(sp <= ep){
				bool forward = false;
				remainder += (read_len1 - new_read_len);
				if(anc_ct.A_rich == false){
					anc_ga.map_pos(sp, ep, ta_rc_read2, read_len1, c_rc_read2, 
						forward, pair_ambiguous, remainder, mates_pairs, ns_rc_read2, false, anc_ct);//only CT-repres has ta/cg-genome
				}
				else{
					anc_ct.map_pos(sp, ep, ta_rc_read1, read_len1, c_rc_read1, 
						forward, pair_ambiguous, remainder, mates_pairs, ns_rc_read1, false, anc_ct);//only CT-repres has ta/cg-genome				
				}
			}//if mapped exactly to forward strand
		}//if BIG SEED > 32
		else{
			_uli new_read_len = min(anc_ga.BIG_SEED, read_len1);
			_uli remainder = new_read_len;
			_uli ta_seed = acgt_rc_read2[0] & anc_ga.mask[new_read_len << 1];
			if(anc_ct.A_rich == false)
				anc_ga.align_linear(ta_seed, sp, ep, new_read_len, remainder);//only first BIG_SEED
			else
				anc_ct.align_linear(ta_seed, sp, ep, new_read_len, remainder);//only first BIG_SEED

			if(sp <= ep){
				bool forward = false;
				remainder += (read_len1 - new_read_len);
			    if(anc_ct.A_rich == false){
					anc_ga.map_pos(sp, ep, ta_rc_read2, read_len1, c_rc_read2, 
						forward, pair_ambiguous, remainder, mates_pairs, ns_rc_read2, false, anc_ct);//only CT-repres has ta/cg-genome
				}
				else{
					anc_ct.map_pos(sp, ep, ta_rc_read1, read_len1, c_rc_read1, 
						forward, pair_ambiguous, remainder, mates_pairs, ns_rc_read1, false, anc_ct);//only CT-repres has ta/cg-genome				
				}
			}//if mapped exactly to forward strand		
		}//BIG SEED = 32
	  }//if read_len > BIG_SEED
	  ////////////////////////////////
	  //this condition goes below BIG_SEED exact match to find all ambiguous with 0 mism
	  if(mates_pairs.mark_unique > 0 && mates_pairs.mism1 == 0)//mapped exactly no need to map with mism because will find with at least 1mism and will be discarded
		  return ;
	  //if mapped exactly, then this condition is not true
	  if(pair_ambiguous == true && mates_pairs.mism1 == 1)
		  return;//if it did not map exactly, there must be at least 1 mism, and 1mism is the best number of mism

	  //////////////////////////////////
		//if mismatch is set in BIG-SEED: go here to find matches with fewer mismatches or to find ambiguous with 1mism
	  pair_ambiguous = false;//need this
		if(anc_ct.first_bits > 0 ){

			bool forward = true;

			_uli new_read_len = min(anc_ct.BIG_SEED, read_len1);

			if(new_read_len <= anc_ct.half_word){
				if(anc_ct.A_rich == false){
					anc_ct.map_pos_mism(acgt_read, ta_read1, read_len1, c_read1, 
							forward, pair_ambiguous, mates_pairs, ns_read1, true, anc_ct);
				}
				else{
					anc_ga.map_pos_mism(acgt_read2, ta_read2, read_len1, c_read2, 
							forward, pair_ambiguous, mates_pairs, ns_read2, true, anc_ct);				
				}
			}
			else{//long here is BIG-SEED: if BIG SEED > 32, then this function is called
				if(anc_ct.A_rich == false){
					anc_ct.map_pos_mism_long(acgt_read, ta_read1, read_len1, c_read1, 
								forward, pair_ambiguous, mates_pairs, ns_read1, true, anc_ct);		
				}
				else{
					anc_ga.map_pos_mism_long(acgt_read2, ta_read2, read_len1, c_read2, 
								forward, pair_ambiguous, mates_pairs, ns_read2, true, anc_ct);						
				}
			}


		}//if mism

	  if(pair_ambiguous == true )
		  return;//if it did not map exactly, there must be at least 1 mism, and 1mism is the best number of mism

	  //Rev-compl AG-representation
		if(anc_ga.first_bits > 0 ){

	
		//reverse reads
			bool forward = false;

			_uli new_read_len = min(anc_ga.BIG_SEED, read_len1);
			if(new_read_len <= anc_ct.half_word){
				if(anc_ct.A_rich == false){
					anc_ga.map_pos_mism(acgt_rc_read2, ta_rc_read2, read_len1, c_rc_read2, 
									forward, pair_ambiguous, mates_pairs, ns_rc_read2, true, anc_ct);
				}
				else{
					anc_ct.map_pos_mism(acgt_rc_read, ta_rc_read1, read_len1, c_rc_read1, 
									forward, pair_ambiguous, mates_pairs, ns_rc_read1, true, anc_ct);				
				}
			}
			else{
				if(anc_ct.A_rich == false){				
					anc_ga.map_pos_mism_long(acgt_rc_read2, ta_rc_read2, read_len1, c_rc_read2, 
									forward, pair_ambiguous, mates_pairs, ns_rc_read2, true, anc_ct);	
				}
				else{
					anc_ct.map_pos_mism_long(acgt_rc_read, ta_rc_read1, read_len1, c_rc_read1, 
									forward, pair_ambiguous, mates_pairs, ns_rc_read1, true, anc_ct);					
				}
			}
		}//rev


}//pair_reads_singles new

void pair_reads_singles_long(_uli read_id, string aread1,
				Stat &astat, _uli read_len1, _uli st1, _uli en1, Mates &mates_pairs , Anchor &anc_ct, Anchor &anc_ga)
{
	//initialization
	anc_ct.init_params(read_len1);
	anc_ga.init_params(read_len1);


	unsigned long int one = 1, mism1, ta_lmer1, cg_lmer1;
	unsigned long int asize,   pos1, dist, i;
	char strand;

	vector<unsigned long int> c_rc_read2, c_read1;//cg-representation
	vector<unsigned long int>  ta_read1, ta_rc_read2;//ta-representation
	vector<_uli> ns_read1, ns_rc_read2;

	unsigned long int start1, end1;
	bool pair_ambiguous = false;

	//get ta-read, cg-read, ns-read: vectors must be empty, we use push_back here
	vector<_uli> acgt_read;
	vector<_uli> acgt_rc_read;
	long int num_ns = anc_ct.convert_lmer_ta_cg(aread1, ta_read1, c_read1, ns_read1, acgt_read, acgt_rc_read, read_len1, mates_pairs);
	if(num_ns > anc_ct.mism_thresh)
		return;

	vector<unsigned long int> ta_read2, c_read2, ns_read2;
	vector<_uli> acgt_read2;
	vector<_uli> acgt_rc_read2;
	num_ns = anc_ga.convert_lmer_ta_cg(aread1, ta_read2, c_read2, ns_read2, acgt_read2, acgt_rc_read2, read_len1, mates_pairs);
	_uli min_shift = (anc_ct.SEED << 1);
	if(anc_ct.MIN_READ < read_len1)
		min_shift = (read_len1 - anc_ct.MIN_READ) << 1;
	_uli cur_shift_delta = min(anc_ct.shift_delta, min_shift);//num_shifts calculated from this

	_uli anew_read_len = read_len1 - anc_ct.SEED;
	if(read_len1 >= anc_ct.MIN_READ )
		anew_read_len = read_len1 - anc_ct.MIN_READ;//was SEED, but we don't want short reads < 48
	_uli num_shifts = min((anew_read_len >> anc_ct.two_in_shift_delta) + 1, anc_ct.max_num_shifts);
	
	//try to match read exactly (fully or partially)


	_uli total_bits = 0;
	for(_uli y = 0; y < num_shifts; y++){
		_uli sp = 0, ep = 0; //retreive_seed shifts these values: have to be 0	
	
		_uli remainder = read_len1;
		if(anc_ct.A_rich == false)
			anc_ct.align_linear(acgt_read, sp, ep, read_len1, remainder, total_bits);//only ta-alignment
		else
			anc_ga.align_linear(acgt_read2, sp, ep, read_len1, remainder, total_bits);//only ta-alignment

		if(sp <= ep){//mapped exactly
			//process forward read1 
			//start and end of list of genome positions for forw1
			bool forward = true;
			if(anc_ct.A_rich == false){
				anc_ct.map_pos(sp, ep, ta_read1, read_len1, c_read1, 
					forward, pair_ambiguous, remainder, mates_pairs, ns_read1, false, anc_ct);
			}
			else{
				anc_ga.map_pos(sp, ep, ta_read2, read_len1, c_read2, 
					forward, pair_ambiguous, remainder, mates_pairs, ns_read2, false, anc_ct);			
			}
	
		}//if mapped exactly to forward strand

		//do all shifts to find ambiguous if all_shifts > 1
			if(pair_ambiguous == true && mates_pairs.mism1 == 0)
				return;

		total_bits += cur_shift_delta ;
		if(total_bits > ((read_len1 - anc_ct.MIN_READ ) << 1))
			break;
	}//for y


	//Map reverse-complement of the read to forward strand

		//take rev-complement of the first read
//NEXT pair reads singles long
	vector<_uli> ta_rc_read1 , c_rc_read1 , ns_rc_read1 ;
		anc_ga.revcompl_lmer_ta_cg(ta_read2, c_read2, ns_read2, read_len1,
			ta_rc_read2, c_rc_read2, ns_rc_read2);
		anc_ct.revcompl_lmer_ta_cg(ta_read1, c_read1, ns_read1, read_len1, ta_rc_read1,
			c_rc_read1, ns_rc_read1);


	//try to match read exactly (fully or partially)

	total_bits = 0;
	for(_uli y = 0; y < num_shifts; y++){
		_uli sp = 0, ep = 0; //retreive_seed shifts these values: have to be 0	

		_uli remainder = read_len1;
		if(anc_ct.A_rich == false)
			anc_ga.align_linear(acgt_rc_read2, sp, ep, read_len1, remainder, total_bits);
		else
			anc_ct.align_linear(acgt_rc_read, sp, ep, read_len1, remainder, total_bits);

		if(sp <= ep){//mapped exactly fully or partially
			//process rev-complemnet of read1 
			bool forward = false;	
			if(anc_ct.A_rich == false){		
				anc_ga.map_pos(sp, ep, ta_rc_read2, read_len1, c_rc_read2, 
					forward, pair_ambiguous, remainder, mates_pairs, ns_rc_read2, false, anc_ct);
			}
			else{
				anc_ct.map_pos(sp, ep, ta_rc_read1, read_len1, c_rc_read1, 
					forward, pair_ambiguous, remainder, mates_pairs, ns_rc_read1, false, anc_ct);			
			}
		}//if mapped exactly (fully or martially) sp <= ep
	//do all shifts to find ambiguous if all_shifts > 1
			if(pair_ambiguous == true && mates_pairs.mism1 == 0)
				return;

		total_bits += cur_shift_delta;
		if(total_bits > ((read_len1 - anc_ct.MIN_READ ) << 1))
			break;
	}//for y

	//if by now did not map exactly, then there is at least 1 mism with 1mism being the best number of mism, hense this condition
	  if(pair_ambiguous == true && mates_pairs.mism1 == 1)
		  return;//if it did not map exactly, there must be at least 1 mism, and 1mism is the best number of mism

	//align exact-match for BIG-SEED: this decreases chance of missing ambiguous in addition to mapping

		bool forward = true;
	if(forward == true){//BIG SEED EXACT
		if(anc_ct.BIG_SEED > anc_ct.half_word){

			_uli new_read_len = min(read_len1, anc_ct.BIG_SEED);

		long int asize_ta = acgt_read.size();
		long int asize_seed = ((new_read_len << 1) >> anc_ct.two_in_Size) + ( ((new_read_len << 1) & anc_ct.mask[anc_ct.two_in_Size]) > 0 ? 1 : 0);
		vector<_uli> ta_seed(asize_seed, 0);
		//bases in the last block
		_uli rest_read_len = read_len1 - ((asize_ta - 1) << anc_ct.two_in_32);

		//how many blocks we need to keep ta_seed:
		_uli total_blocks = asize_seed ;//the last 1 holds rest_read_len

		//index of the first block keeping ta_seed
		_uli first_block = asize_ta - total_blocks;
		_uli ta_seed1 = 0, c_seed1 = 0, ns_seed1 = 0;


		_uli rem_unused_bits = ((total_blocks - 1) << anc_ct.two_in_Size) - ((new_read_len - rest_read_len) << 1);
		int seed_ind = 0;
		int y = first_block;
		if(anc_ct.A_rich == false){

			for(; y < asize_ta - 2; y++){
				ta_seed[seed_ind] = (acgt_read[y] >> rem_unused_bits)| (acgt_read[y + 1] << (anc_ct.SIZE - rem_unused_bits));
				seed_ind++;
			}//for y
			ta_seed[seed_ind] = (acgt_read[y] >> rem_unused_bits) ;
			y++;
			if(rem_unused_bits < (rest_read_len << 1)){
				ta_seed[seed_ind] |= ((acgt_read[y] & anc_ct.mask[rem_unused_bits])) << (anc_ct.SIZE - rem_unused_bits);
				seed_ind++;
				ta_seed[seed_ind] = (acgt_read[y] >> rem_unused_bits);
			}
			else{
				ta_seed[seed_ind] |= acgt_read[y] << (anc_ct.SIZE - rem_unused_bits);
			}
		}//if A false
		else{
			for(; y < asize_ta - 2; y++){
				ta_seed[seed_ind] = (acgt_read2[y] >> rem_unused_bits)| (acgt_read2[y + 1] << (anc_ct.SIZE - rem_unused_bits));
				seed_ind++;
			}//for y
			ta_seed[seed_ind] = (acgt_read2[y] >> rem_unused_bits) ;
			y++;
			if(rem_unused_bits < (rest_read_len << 1)){
				ta_seed[seed_ind] |= ((acgt_read2[y] & anc_ct.mask[rem_unused_bits])) << (anc_ct.SIZE - rem_unused_bits);
				seed_ind++;
				ta_seed[seed_ind] = (acgt_read2[y] >> rem_unused_bits);
			}
			else{
				ta_seed[seed_ind] |= acgt_read2[y] << (anc_ct.SIZE - rem_unused_bits);
			}		
		}//if A true
		//1-bit representation

			_uli remainder = new_read_len;

			_uli sp = 0, ep = 0;

			if(anc_ct.A_rich == false)
				anc_ct.align_linear_seed(ta_seed, sp, ep, new_read_len, remainder, 0);//only first BIG_SEED
			else
				anc_ga.align_linear_seed(ta_seed, sp, ep, new_read_len, remainder, 0);//only first BIG_SEED
			if(sp <= ep){
				if(anc_ct.A_rich == false){
					anc_ct.map_pos(sp, ep, ta_read1, read_len1, c_read1, 
						forward, pair_ambiguous, remainder, mates_pairs, ns_read1, true, anc_ct);
				}
				else{
					anc_ga.map_pos(sp, ep, ta_read2, read_len1, c_read2, 
						forward, pair_ambiguous, remainder, mates_pairs, ns_read2, true, anc_ct);				
				}
			}//if
		}//if BIG_SEED > 32
		else{
			_uli new_read_len = min(anc_ct.BIG_SEED, read_len1);
			_uli remainder = new_read_len;

			_uli sp = 0, ep = 0;
			_uli ta_seed = 0;

			long int asize_ta = acgt_read.size();
			_uli rest_read_len = read_len1 - ((asize_ta - 1) << anc_ct.two_in_32);

			if(anc_ct.A_rich == false){
				if(rest_read_len >= new_read_len){
					ta_seed = acgt_read[asize_ta - 1] >> ((rest_read_len - new_read_len) << 1);
				}
				else{
					ta_seed = (acgt_read[asize_ta - 1] << ((new_read_len - rest_read_len) << 1)) | 
						(acgt_read[asize_ta - 2] >> (anc_ct.SIZE - ((new_read_len - rest_read_len) << 1)));
					}
			}//if A false
			else{
				if(rest_read_len >= new_read_len){
					ta_seed = acgt_read2[asize_ta - 1] >> ((rest_read_len - new_read_len) << 1);
				}
				else{
					ta_seed = (acgt_read2[asize_ta - 1] << ((new_read_len - rest_read_len) << 1)) | 
						(acgt_read2[asize_ta - 2] >> (anc_ct.SIZE - ((new_read_len - rest_read_len) << 1)));
					}			
			}//A true

			if(anc_ct.A_rich == false)
				anc_ct.align_linear(ta_seed, sp, ep, new_read_len, remainder);//only first BIG_SEED
			else
				anc_ga.align_linear(ta_seed, sp, ep, new_read_len, remainder);//only first BIG_SEED
		
			if(sp <= ep){
				if(anc_ct.A_rich == false){
					anc_ct.map_pos(sp, ep, ta_read1, read_len1, c_read1, 
						forward, pair_ambiguous, remainder, mates_pairs, ns_read1, true, anc_ct);
				}
				else{
					anc_ga.map_pos(sp, ep, ta_read2, read_len1, c_read2, 
						forward, pair_ambiguous, remainder, mates_pairs, ns_read2, true, anc_ct);				
				}
			}//if
		
		}//else if BIG SEED = 32
	}//forw BIG SEED

		if(pair_ambiguous == true && mates_pairs.mism1 == 0)
			return;
 
	  //if mapped exactly, then this condition is not true
	  if(pair_ambiguous == true && mates_pairs.mism1 == 1)
		  return;//if it did not map exactly, there must be at least 1 mism, and 1mism is the best number of mism

	  //rev-compl AG-repres
	
		forward = false;	
		if(forward == false){//BIG SEED REV

		if(anc_ct.BIG_SEED > anc_ct.half_word){

		_uli new_read_len = min(read_len1, anc_ct.BIG_SEED);

		long int asize_ta = acgt_rc_read2.size();
		long int asize_seed = ((new_read_len << 1) >> anc_ct.two_in_Size) + ( ((new_read_len << 1) & anc_ct.mask[anc_ct.two_in_Size]) > 0 ? 1 : 0);
		vector<_uli> ta_seed(asize_seed, 0);
		//bases in the last block
		//how many blocks we need to keep ta_seed:
		_uli total_blocks = asize_seed ;//the last 1 holds rest_read_len
		//index of the first block keeping ta_seed
		_uli first_block = asize_ta - total_blocks;

			//also assumption is this function gets BIG-SEEDS that are > 32 bases
			_uli rest_bits = anc_ct.SIZE - ((anc_ct.SIZE << 1) - (new_read_len << 1));//assumption is that BIG_SEED is max 62 bases
		if(anc_ct.A_rich == false){
			ta_seed[0] = acgt_rc_read2[0];
			ta_seed[1] = acgt_rc_read2[1] & anc_ct.mask[rest_bits];
		}
		else{
			ta_seed[0] = acgt_rc_read[0];
			ta_seed[1] = acgt_rc_read[1] & anc_ct.mask[rest_bits];		
		}
			_uli remainder = new_read_len;
			_uli sp = 0, ep = 0;
			if(anc_ct.A_rich == false)
				anc_ga.align_linear_seed(ta_seed, sp, ep, new_read_len, remainder, 0);//only first BIG_SEED
			else
				anc_ct.align_linear_seed(ta_seed, sp, ep, new_read_len, remainder, 0);//only first BIG_SEED

			if(sp <= ep){
				bool forward = false;
				remainder += (read_len1 - new_read_len);
				if(anc_ct.A_rich == false){
					anc_ga.map_pos(sp, ep, ta_rc_read2, read_len1, c_rc_read2, 
						forward, pair_ambiguous, remainder, mates_pairs, ns_rc_read2, false, anc_ct);//only CT-repres has ta/cg-genome
				}
				else{
					anc_ct.map_pos(sp, ep, ta_rc_read1, read_len1, c_rc_read1, 
						forward, pair_ambiguous, remainder, mates_pairs, ns_rc_read1, false, anc_ct);//only CT-repres has ta/cg-genome				
				}//else
			}//if mapped exactly to forward strand
		}//if BIG SEED > 32
		else{
			_uli new_read_len = min(anc_ga.BIG_SEED, read_len1);
			_uli remainder = new_read_len;
			_uli ta_seed = 0;
			if(anc_ct.A_rich == false)
				ta_seed = acgt_rc_read2[0] & anc_ga.mask[new_read_len << 1];
			else
				ta_seed = acgt_rc_read[0] & anc_ga.mask[new_read_len << 1];

			_uli sp = 0, ep = 0;
			if(anc_ct.A_rich == false)
				anc_ga.align_linear(ta_seed, sp, ep, new_read_len, remainder);//only first BIG_SEED
			else
				anc_ct.align_linear(ta_seed, sp, ep, new_read_len, remainder);//only first BIG_SEED

			if(sp <= ep){
				bool forward = false;
				remainder += (read_len1 - new_read_len);
				if(anc_ct.A_rich == false){
					anc_ga.map_pos(sp, ep, ta_rc_read2, read_len1, c_rc_read2, 
						forward, pair_ambiguous, remainder, mates_pairs, ns_rc_read2, false, anc_ct);//only CT-repres has ta/cg-genome
				}
				else{
					anc_ct.map_pos(sp, ep, ta_rc_read1, read_len1, c_rc_read1, 
						forward, pair_ambiguous, remainder, mates_pairs, ns_rc_read1, false, anc_ct);//only CT-repres has ta/cg-genome				
				}
			}//if mapped exactly to forward strand		
		}//BIG SEED = 32
		}//BIG SEED FOR REV

	  //this condition goes below BIG_SEED exact match to find all ambiguous with 0 mism
	  if(mates_pairs.mark_unique > 0 && mates_pairs.mism1 == 0)//mapped exactly no need to map with mism because will find with at least 1mism and will be discarded
		  return ;

	
				if(pair_ambiguous == true && (mates_pairs.mism1 == 0 || mates_pairs.mism1 == 1))
				return;

		//if mismatch is set in BIG-SEED: go here to find matches with fewer mismatches or to find ambiguous with 1mism
	  pair_ambiguous = false;//need this, if so far we have pair_amb with mism > 1, we use here pair_ambiguous on seeds
	  //and seeds have mism = 1
		if(anc_ct.first_bits > 0 ){

			bool forward = true;

			_uli new_read_len = min(anc_ct.BIG_SEED, read_len1);

			if(new_read_len <= anc_ct.half_word){
				if(anc_ct.A_rich == false){
					anc_ct.map_pos_mism(acgt_read, ta_read1, read_len1, c_read1, 
								forward, pair_ambiguous, mates_pairs, ns_read1, true, anc_ct);
				}
				else{
					anc_ga.map_pos_mism(acgt_read2, ta_read2, read_len1, c_read2, 
								forward, pair_ambiguous, mates_pairs, ns_read2, true, anc_ct);				
				}
			}
			else{//long here is BIG-SEED: if BIG SEED > 32, then this function is called
				if(anc_ct.A_rich == false){
					anc_ct.map_pos_mism_long(acgt_read, ta_read1, read_len1, c_read1, 
							forward, pair_ambiguous, mates_pairs, ns_read1, true, anc_ct);			
				}
				else{
					anc_ga.map_pos_mism_long(acgt_read2, ta_read2, read_len1, c_read2, 
							forward, pair_ambiguous, mates_pairs, ns_read2, true, anc_ct);						
				}
			}


		}//if mism

	  if(pair_ambiguous == true )
		  return;//if it did not map exactly, there must be at least 1 mism, and 1mism is the best number of mism

	  //Rev-compl AG-representation
		if(anc_ga.first_bits > 0 ){

	
		//reverse reads
			bool forward = false;

			_uli new_read_len = min(anc_ga.BIG_SEED, read_len1);
			if(new_read_len <= anc_ct.half_word){
				if(anc_ct.A_rich == false){
					anc_ga.map_pos_mism(acgt_rc_read2, ta_rc_read2, read_len1, c_rc_read2, 
									forward, pair_ambiguous, mates_pairs, ns_rc_read2, true, anc_ct);
				}
				else{
					anc_ct.map_pos_mism(acgt_rc_read, ta_rc_read1, read_len1, c_rc_read1, 
									forward, pair_ambiguous, mates_pairs, ns_rc_read1, true, anc_ct);				
				}
			}
			else{
				if(anc_ct.A_rich == false){
					anc_ga.map_pos_mism_long(acgt_rc_read2, ta_rc_read2, read_len1, c_rc_read2, 
								forward, pair_ambiguous, mates_pairs, ns_rc_read2, true, anc_ct);			
				}
				else{
					anc_ct.map_pos_mism_long(acgt_rc_read, ta_rc_read1, read_len1, c_rc_read1, 
								forward, pair_ambiguous, mates_pairs, ns_rc_read1, true, anc_ct);					
				}
			}
		}//rev

}//pair_reads_singles_long new


//PAIRED_END reads
void pair_reads(_uli read_id, string aread1,
				Stat &astat, _uli read_len1, _uli st1, _uli en1,
				string aread2, _uli read_len2, _uli st2, _uli en2 , Anchor &anc_ct, Anchor &anc_ga)
{
	//initialization
	Mates mates_pairs1, mates_pairs2;
	
	anc_ct.A_rich = false; anc_ga.A_rich = false;
	if((read_len1 >= anc_ct.MIN_READ) && (read_len1 <= anc_ct.SIZE)){
		pair_reads_singles(read_id, aread1, astat, read_len1, st1, en1, mates_pairs1, anc_ct, anc_ga);

	}
	else if(read_len1 > anc_ct.SIZE){
		pair_reads_singles_long(read_id, aread1, astat, read_len1, st1, en1, mates_pairs1, anc_ct, anc_ga);
	}


	anc_ct.A_rich = true;
	anc_ga.A_rich = true;

	if((read_len2 >= anc_ct.MIN_READ) && (read_len2 <= anc_ct.SIZE)){
		pair_reads_singles(read_id, aread2, astat, read_len2, st2, en2, mates_pairs2, anc_ct, anc_ga);
	
	}
	else if(read_len2 > anc_ct.SIZE){
		pair_reads_singles_long(read_id, aread2, astat, read_len2, st2, en2, mates_pairs2, anc_ct, anc_ga);

	}

	if(anc_ct.four_strands == true){
		if(mates_pairs1.mark_unique < 2){
			anc_ct.A_rich = true;
			anc_ga.A_rich = true;

			if((read_len1 >= anc_ct.MIN_READ) && (read_len1 <= anc_ct.SIZE)){
				pair_reads_singles(read_id, aread1, astat, read_len1, st1, en1, mates_pairs1, anc_ct, anc_ga);
			}
			else if(read_len1 > anc_ct.SIZE){
				pair_reads_singles_long(read_id, aread1, astat, read_len1, st1, en1, mates_pairs1, anc_ct, anc_ga);
			}
		}//if not already ambiguous
		if(mates_pairs2.mark_unique < 2){
			anc_ct.A_rich = false; 
			anc_ga.A_rich = false;

			if((read_len2 >= anc_ct.MIN_READ) && (read_len2 <= anc_ct.SIZE)){
				pair_reads_singles(read_id, aread2, astat, read_len2, st2, en2, mates_pairs2, anc_ct, anc_ga);
			}
			else if(read_len2 > anc_ct.SIZE){
				pair_reads_singles_long(read_id, aread2, astat, read_len2, st2, en2, mates_pairs2, anc_ct, anc_ga);
			}	
		}//if read2 is not already ambiguous
	}

	anc_ct.A_rich = false; anc_ga.A_rich = false;
	anc_ct.print_pairs(read_id, aread1, read_len1, st1, en1, mates_pairs1, aread2, read_len2, st2, en2, mates_pairs2, astat);

}//pair_reads

//END PAIRED END READS

void Anchor::ta_match(const _uli &read_len1, const _uli &pos1, const _uli &ta_read1, _uli &ta_check, 
	const _uli &ns_read1, int &mism1, const Anchor &anc)
{
	_uli ta_gen_mer1 = 0;
	convert_gen_mer_ta(ta_gen_mer1, pos1, read_len1, anc);
	ta_check |= (ta_read1 ^ ta_gen_mer1) | ns_read1;
	mism1 = 0;//ta_check contains already mism from cg-match
	mism1 = count_mism(ta_check);
}//ta_match

//for short, fixed-length = 32bp readds only
int Anchor::cg_match(const _uli &read_len1, const _uli &pos1, const _uli &ta_read1, const _uli &c_read1,
	_uli &ta_check, const bool &forward, bool &cg_mism1, const _uli &ns_read1, const Anchor &anc)
{
	_uli cg_gen_mer1 = 0;
	convert_gen_mer_cg(cg_gen_mer1, pos1, read_len1, anc);
	_uli cg_check = 0;
	if(A_rich == false){
		if(forward){
			count_ag_mism(ta_read1, c_read1, cg_gen_mer1, ta_check);
			if(allow_C_to_T == 1){ //does not allow G->A in forward read
				_uli g_read = (~ta_read1) & c_read1;
				cg_check = g_read ^ (g_read & cg_gen_mer1);
			}
		}
		else{
			count_tc_mism(ta_read1, c_read1, cg_gen_mer1, ta_check);
			if(allow_C_to_T == 1){ //does not allow G->A in forward read
				_uli c_only_read = ta_read1 & c_read1;
				cg_check = c_only_read ^ (c_only_read & cg_gen_mer1);
			}
		}
	}
	else{
		if(forward == false){
			count_ag_mism(ta_read1, c_read1, cg_gen_mer1, ta_check);
			if(allow_C_to_T == 1){ //does not allow G->A in forward read
				_uli g_read = (~ta_read1) & c_read1;
				cg_check = g_read ^ (g_read & cg_gen_mer1);
			}
		}
		else{
			count_tc_mism(ta_read1, c_read1, cg_gen_mer1, ta_check);	
			if(allow_C_to_T == 1){ //does not allow G->A in forward read
				_uli c_only_read = ta_read1 & c_read1;
				cg_check = c_only_read ^ (c_only_read & cg_gen_mer1);
			}
		}
	}//else
	// need tc/ag-match because 2-bit repres does not map entire read

	
	if(allow_C_to_T == 0)
		cg_check = c_read1 ^ (c_read1 & cg_gen_mer1);

	//count total mism
	ta_check |= cg_check | ns_read1;
	int mism1 = count_mism(ta_check);//total_mismatches

	return mism1;

}//cg_check

void Anchor::ta_match(const _uli &read_len1, const _uli &pos1, const vector<_uli> &ta_read1, vector<_uli> &ta_check, 
	const vector<_uli> &ns_read1, int &mism1, const Anchor &anc)
{
	//ta_check must be declared and initialized with zeros outside this function before it's call
	vector<_uli> ta_gen_mer1;
	convert_gen_mer_ta(ta_gen_mer1, pos1, read_len1, anc);
	int asize = ta_read1.size();
	mism1 = 0;
	for(int j =0; j < asize; j++){
		ta_check[j] |= (ta_read1[j] ^ ta_gen_mer1[j]) | ns_read1[j];
		mism1 += count_mism(ta_check[j]);
		if(mism1 > mism_thresh){
			break;
		}//if
	}

}//ta_match long

int Anchor::cg_match(const _uli &read_len1, const _uli &pos1, const vector<_uli> &ta_read1, const vector<_uli> &c_read1,
	vector<_uli> &ta_check, const bool &forward, bool &cg_mism1, const vector<_uli> &ns_read1, const Anchor &anc)
{
	int asize = ta_read1.size();

	vector<_uli> cg_gen_mer1;
	convert_gen_mer_cg(cg_gen_mer1, pos1, read_len1, anc);

	if(A_rich == false){
		if(forward){
			count_ag_mism(ta_read1, c_read1, cg_gen_mer1, ta_check);
		}
		else
			count_tc_mism(ta_read1, c_read1, cg_gen_mer1, ta_check);
	}//if
	else{
		if(forward == false){
			count_ag_mism(ta_read1, c_read1, cg_gen_mer1, ta_check);
		}
		else
			count_tc_mism(ta_read1, c_read1, cg_gen_mer1, ta_check);	
	}//else
	//this is already checked 
	//do cg-check and count mism

	_uli mism1 = 0;	
	for(int j = 0; j < asize; j++){
		if(allow_C_to_T == 0)
			ta_check[j] |= (c_read1[j] ^ (c_read1[j] & cg_gen_mer1[j])) ;
		else{
			_uli c_only_read = ta_read1[j] & c_read1[j];
			_uli g_only_read = (~(ta_read1[j])) & c_read1[j];
			if(A_rich == false){
				if(forward == true){
					ta_check[j] |= g_only_read ^ (g_only_read & cg_gen_mer1[j]);
				}//forward
				else{
					ta_check[j] |= c_only_read ^ (c_only_read & cg_gen_mer1[j]);
				}//rev-compl
			}//A_rich false
			else{
				if(forward == true){
					ta_check[j] |= c_only_read ^ (c_only_read & cg_gen_mer1[j]);				
				}//forward
				else{
					ta_check[j] |= g_only_read ^ (g_only_read & cg_gen_mer1[j]);				
				}//rev
			}//A_rich is true
		}//allow_C_to_T is true
	  mism1 += count_mism(ta_check[j]);
	  if(mism1 > mism_thresh){
		  cg_mism1 = true;
		  break;
	  }
	}//for j
	return mism1;
}//cg_match long 


//for BISULFITE reads FIRST mates

void Anchor::count_ag_mism(const _uli &ta_read1, const _uli &c_read1, const _uli &cg_gen_mer1,
	_uli &ta_check)
{
	_uli ag_mism1 = (~(ta_read1 | c_read1)) & cg_gen_mer1;
	ta_check |= ag_mism1;
}//count_ag_mism

void Anchor::count_ag_mism(const vector<_uli> &ta_read1, const vector<_uli> &c_read1, const vector<_uli> &cg_gen_mer1,
	vector<_uli> &ta_check)
{
	int asize = ta_read1.size();
	for(int j = 0; j < asize; j++)
		ta_check[j] |= (~(ta_read1[j] | c_read1[j])) & cg_gen_mer1[j];

}//count_ag_mism

void Anchor::count_tc_mism(const _uli &ta_read1, const _uli &c_read1, const _uli &cg_gen_mer1,
	_uli &ta_check)
{
	_uli ag_mism1 = (ta_read1 &(~c_read1)) & cg_gen_mer1;
	ta_check |= ag_mism1;
}//count_ag_mism

void Anchor::count_tc_mism(const vector<_uli> &ta_read1, const vector<_uli> &c_read1, const vector<_uli> &cg_gen_mer1,
	vector<_uli> &ta_check)
{
	int asize = ta_read1.size();
	for(int j = 0; j < asize; j++)
		ta_check[j] |= (ta_read1[j] &(~c_read1[j])) & cg_gen_mer1[j];
}//count_ag_mism

//end BISULFITE reads FIRST mates

void Anchor::update_singles(Mates &mates_pairs, const char &strand,
	const _ui &pos1, const _usi &mism1, bool &pair_ambiguous, bool map_mism)
{
	if(mates_pairs.mark_unique == 0){
		mates_pairs.mark_unique++;
		mates_pairs.pos1 = pos1;
		mates_pairs.strand = strand;//by the first read
		mates_pairs.mism1 = mism1;
		pair_ambiguous = false;
		mates_pairs.A_rich = A_rich;
	}//if
	else if(mates_pairs.pos1 != pos1 || mates_pairs.strand != strand || mates_pairs.A_rich != A_rich){
		if(mism1 < mates_pairs.mism1){
			//unique
			mates_pairs.mark_unique = 1;
			mates_pairs.pos1 = pos1;
			mates_pairs.strand = strand;//by the first read
			mates_pairs.mism1 = mism1;			
			pair_ambiguous = false;
			mates_pairs.A_rich = A_rich;
		}
		else if(mism1 == mates_pairs.mism1){
			mates_pairs.mark_unique++;
			if(mism1 == 0)
				pair_ambiguous = true;
	
			if(map_mism == true && mism1 == 1)//does not affect accuracy, but speeds up significantly
				pair_ambiguous = true;
			}
	}//else		

}//update_singles


long int Anchor::convert_lmer_ta_cg(string lmer, _uli &ta, _uli &cg, _uli &ns, vector<_uli> &full, vector<_uli> &full_rc, 
	_ui asize, Mates &mates_pairs){
	long int num_ns = 0;
	_uli j;
	ta = 0; 
	ns = 0;
	cg = 0;
	full.resize(2, 0);
	full_rc.resize(2, 0);//read at most 64bases, 2-bit representation takes 2 _uli
	string aread_rc = lmer;
	reverse(aread_rc.begin(), aread_rc.end());

	for(j = 0; j < asize; j++){
		if(j < half_word){
		  
			full[0] <<= 2;

		}
		else
			full[1] <<= 2;
		ta <<= 1;
		ns <<= 1;
		cg <<= 1;
		if(lmer[j] == 'T' || lmer[j] == 't') {
			ta |= 1;
			if(j < half_word)
				full[0] |= 3;
			else
				full[1] |= 3;
		}
		else if(lmer[j] == 'C' || lmer[j] == 'c'){
			ta |= 1;
			cg |= 1;
			if(j < half_word){
			  if(Genome == 1 )
				full[0] |= 3;
			  else 
				  full[0] |= 1;
			}
			else{
			  if(Genome == 1)
				full[1] |= 3;
			  else 
				full[1] |= 1;
			}//if j < half_word
			mates_pairs.is_cg = true;
		}
		else if(lmer[j] == 'G' || lmer[j] == 'g'){
			cg |= 1;
			mates_pairs.is_cg = true;
			if(j < half_word){
				if(Genome == 1)
					full[0] |= 2;
			}
			else{
				if(Genome == 1 )
					full[1] |= 2;

			}
		}
		else if(lmer[j] == 'N' || lmer[j] == 'n'){
			ns |= 1;
			num_ns++;
		}

	}//for j
	if(asize > half_word){
		_uli rest_bits = (asize - half_word) << 1;
		full[1] = full[1] | ((full[0] & mask[SIZE - rest_bits]) << rest_bits);
		full[0] = full[0] >> (SIZE - rest_bits);
		_uli atemp = full[0];
		full[0] = full[1];
		full[1] = atemp;
	}
	//complement of reverse
	for(j = 0; j < asize; j++){

		if(j < half_word)
			full_rc[0] <<= 2;
		else
			full_rc[1] <<= 2;

		if(aread_rc[j] == 'T' || aread_rc[j] == 't') {
			if(j < half_word)
				full_rc[0] |= 0;
			else
				full_rc[1] |= 0;
		}//T
		else if(aread_rc[j] == 'C' || aread_rc[j] == 'c'){
			if(j < half_word){//compl of C is G
				if(Genome == 1 )
					full_rc[0] |= 2;
			}
			else{
				if(Genome == 1)
					full_rc[1] |= 2;
			}//else
			
		}//C
		else if(aread_rc[j] == 'G' || aread_rc[j] == 'g'){
			if(j < half_word){//compl = C
			  if(Genome == 1 )
				full_rc[0] |= 3;
			  else 
				  full_rc[0] |= 1;
			}
			else{
			  if(Genome == 1 )
				full_rc[1] |= 3;
			  else 
				  full_rc[1] |= 1;
			}
		}//G
		else{
			if(j < half_word)
				full_rc[0] |= 3;
			else
				full_rc[1] |= 3;
			
		}//A, N

	}//for j

	if(asize > half_word){
		_uli rest_bits = (asize - half_word) << 1;
		full_rc[1] = full_rc[1] | ((full_rc[0] & mask[SIZE - rest_bits]) << rest_bits);
		full_rc[0] = full_rc[0] >> (SIZE - rest_bits);
		_uli atemp = full_rc[0];
		full_rc[0] = full_rc[1];
		full_rc[1] = atemp;
	}
	return num_ns;
}//convert_ta_cg

long int Anchor::convert_lmer_ta_cg(string lmer, vector<_uli> &ta_read, vector<_uli> &cg_read, vector<_uli> &ns_read, 
	vector<_uli> &full, vector<_uli> &full_rc, _ui read_len, Mates &mates_pairs){

	long int num_ns = 0;

	int asize = (read_len >> two_in_Size) + ((read_len & mask[two_in_Size]) > 0 ? 1 : 0) ;
	int full_size = (read_len >> two_in_32) + ((read_len & mask[two_in_32]) > 0 ? 1 : 0);

	full.resize(full_size, 0);
	full_rc.resize(full_size, 0);
	int full_ind = 0;

	ta_read.resize(asize, 0);
	cg_read.resize(asize, 0);
	ns_read.resize(asize, 0);
	int ind = 0;
	int i = 0;
	while(i < read_len){
		_uli ta = 0, cg = 0, ns = 0;
		for(int j = 0; (j < SIZE) && (i < read_len); j++){
			ta <<= 1;
			ns <<= 1;
			cg <<= 1;
			full[full_ind] <<= 2;

			if(lmer[i] == 'T' || lmer[i] == 't') {
				ta |= 1;
				full[full_ind] |= 3;
			}
			else if(lmer[i] == 'C' || lmer[i] == 'c'){
				ta |= 1;
				cg |= 1;
				mates_pairs.is_cg = true;
			  if(Genome == 1)
				full[full_ind] |= 3;
			  else 
					full[full_ind] |= 1;
			}
			else if(lmer[i] == 'G' || lmer[i] == 'g'){
				cg |= 1;
				if(Genome == 1 )
					full[full_ind] |= 2;
				mates_pairs.is_cg = true;
			}
			else if(lmer[i] == 'N' || lmer[i] == 'n'){
				ns |= 1;
				num_ns++;
			}	
			i++;
			if((i & mask[two_in_32]) == 0)
				full_ind++;
		}//for j
		ta_read[ind] = ta;
		cg_read[ind] = cg;
		ns_read[ind] = ns;
		ind++;

	}//while

	int rest_bits = read_len & mask[two_in_Size];//= (read_len1 mod SIZE) 
	if(rest_bits > 0){
		shift_back(ta_read, asize, rest_bits);
		shift_back(cg_read, asize, rest_bits);
		shift_back(ns_read, asize, rest_bits);
	}
	reverse(ta_read.begin(), ta_read.end());
	reverse(cg_read.begin(), cg_read.end());
	reverse(ns_read.begin(), ns_read.end());

	string aread_rc = lmer;
	reverse(aread_rc.begin(), aread_rc.end());
	i = 0;

	full_ind = 0;
	while( i < read_len){

			full_rc[full_ind] <<= 2;
			if(aread_rc[i] == 'T' || aread_rc[i] == 't') {
				full_rc[full_ind] |= 0;
			}
			else if(aread_rc[i] == 'C' || aread_rc[i] == 'c'){
				if(Genome == 1 )//complement of C is G, for G:
					full_rc[full_ind] |= 2;
			}
			else if(aread_rc[i] == 'G' || aread_rc[i] == 'g'){//complement of G is C, for C:
			  if(Genome == 1)
				full_rc[full_ind] |= 3;
			  else 
					full_rc[full_ind] |= 1;
			}
			else{
				full_rc[full_ind] |= 3;
			}	
			i++;
			if((i & mask[two_in_32]) == 0)
				full_ind++;
		}//for i

	rest_bits = (read_len & mask[two_in_32]) << 1;
	if(rest_bits > 0){
		shift_back(full, full_size, rest_bits);
		shift_back(full_rc, full_size, rest_bits);
	}
	reverse(full.begin(), full.end());
	reverse(full_rc.begin(), full_rc.end());

	return num_ns;
}//convert_ta_cg
void Anchor::shift_back(vector<_uli> &ta_read, int asize, const _ui &rest_bits)
{
	asize--;//last index, asize is size of ta
	//rest_bits is rest of bits of a read, when taking multiple of 64
	for(int i = asize; i > 0; i--){
		_uli prev_ta = ta_read[i - 1] << rest_bits;
		ta_read[i] |= prev_ta;
		ta_read[i-1] >>= SIZE - rest_bits;

	}//for i

	//now full first entries correspond to the end of read
}//shift_back

void Anchor::revcompl_lmer_ta_cg(const vector<_uli> &ta_read, const vector<_uli> &cg_read, const vector<_uli> &ns_read, const _ui &read_len,
	vector<_uli> &ta_rc_read, vector<_uli> &cg_rc_read, vector<_uli> &ns_rc_read)
{	
/*
1111111011111110000101101101101111101101100101111111100000100010
000100010101010000010101010101010101
*/
	int len1 = read_len & mask[two_in_Size];//= (read_len1 mod SIZE) 
	if(len1 == 0)
		len1 = SIZE;
	_uli one = 1;
	unsigned long int MASK_READ;
	if(len1 < SIZE){
		MASK_READ = ( one << len1) - 1;
	}
	else
		MASK_READ = 0xFFFFFFFFFFFFFFFF;

	int asize = ta_read.size();
	ta_rc_read.resize(asize);
	cg_rc_read.resize(asize);
	ns_rc_read.resize(asize);

	int stop = asize - 1;
	for(int i = 0; i < stop; i++){
		ta_rc_read[i] = ~Reverse(ta_read[i], SIZE);
		cg_rc_read[i] =  Reverse(cg_read[i], SIZE);//shows positions of Gs in reverse strand
		ns_rc_read[i] = Reverse(ns_read[i], SIZE);
	}
	ta_rc_read[stop] = MASK_READ & (~Reverse(ta_read[stop], len1));
	cg_rc_read[stop] =  MASK_READ & Reverse(cg_read[stop], len1);//shows positions of Gs in reverse strand
	ns_rc_read[stop] = Reverse(ns_read[stop], len1) & MASK_READ;

	//shift to make rev-compl in same order, i.e. first entry contain last bits of rev-compl
	shift_back(ta_rc_read, asize, len1);
	shift_back(cg_rc_read, asize, len1);
	shift_back(ns_rc_read, asize, len1);

	reverse(ta_rc_read.begin(), ta_rc_read.end());
	reverse(cg_rc_read.begin(), cg_rc_read.end());
	reverse(ns_rc_read.begin(), ns_rc_read.end());

}//revcompl_lmer_ta_cg

int Anchor::parse_options(int argc, char* argv[])
{
	int res = 0;

	long int i, j;
	for(i = 1; i < argc; i++){
		if(argv[i][0] != '-')
			return -1;
		switch(argv[i][1]){
		case 'P': prefix = argv[++i]; break;
		case 's': reads_file1 = argv[++i]; break;
		case '1': reads_file1 = argv[++i]; break;
		case '2': reads_file2 = argv[++i]; break;
		case 'o': output_pairs = argv[++i]; break;
		case 'p': is_pe = "1"; break;
		case 'i': min_insert = atoi(argv[++i]); break;
		case 'a': max_insert = atoi(argv[++i]); break;
		case 'A': A_rich = true; break;
		case 'm': mism_thresh = atoi(argv[++i]); break;
		case 'F': first_bits = atoi(argv[++i]); break;
		case 'C': allow_C_to_T = 1; break;
		case 'D': max_shift_delta = atoi(argv[++i]); break;
		case 'K': max_num_shifts = atoi(argv[++i]); break;
		case 'W': four_strands = true; break;
		case 'h': usage(); break;
		default: cerr << "ERROR: Invalid char=" << argv[i][1] << "=this" << endl; usage(); space_release(); exit(0); break;
		}
	}//for i
//Depricated:
//		case 'u': unmapped = true; break;
//		case 'k': all_shifts = atoi(argv[++i]); break;
//		case 'b': is_bs = "1"; break;
//		case 'M': out_amb = true; break;
//		case 'f': BIG_SEED = atoi(argv[++i]); break;

	return res;
}//parse_opt()
void Anchor::read_rev_complement(string &aread, const _uli  &read_len){
	reverse(aread.begin(), aread.end());

	for(_uli i = 0; i < read_len; i++){
		if(aread[i] == 'T' || aread[i] == 't')
			aread[i] = 'A';
		else if(aread[i] == 'A' || aread[i] == 'a')
			aread[i] = 'T';
		else if(aread[i] == 'G' || aread[i] == 'g')
			aread[i] = 'C';
		else if(aread[i] == 'C' || aread[i] == 'c')
			aread[i] = 'G';
		else
			aread[i] = 'N';
	}//for i
}//read_rev_complement

void Anchor::print_pairs(const _uli &read_id, const string &aread1, const _uli &read_len1, const _uli &st1,
		const _uli & en1, Mates &mates_pairs1, const string &aread2, const _uli &read_len2, 
		const _uli &st2, const _uli &en2, Mates &mates_pairs2, Stat &astat)
{


	long int orig_start1, orig_start2;

	if((mates_pairs1.mark_unique == 1) && (mates_pairs2.mark_unique == 1)){

		//determine chrom id for this read
		long int chrom_id1 = 0, chrom_id2 = 0;

		//find the first start of chrom that is greater than pos
		long int pos1 = mates_pairs1.pos1; 
		long int asize = size_chrom.size();
		for(long int i = 0; i < asize; i++){
			if(pos1 >= starts_size_chrom[i])
				chrom_id1++;
			else
				break;
		}//for i
		chrom_id1--;
		pos1 = pos1 - starts_size_chrom[chrom_id1];

		long int pos2 = mates_pairs2.pos1;//must by signed
		for(long int i = 0; i < asize; i++){
			if(pos2 >= starts_size_chrom[i])
				chrom_id2++;
			else
				break;
		}//for i
		chrom_id2--;
		pos2 = pos2 - starts_size_chrom[chrom_id2];

		if(chrom_id1 == chrom_id2){
			char strand1 = mates_pairs1.strand;
			char strand2 = mates_pairs2.strand;
			if((strand1 == '+' && strand2 == '-') || (strand1 == '-' && strand2 == '+')){
				//check if insert is correct
				long int dist =  pos2 - pos1;
				if(strand1 == '-')
					dist = pos1 - pos2;
				if(mates_pairs1.A_rich == true)
					dist = -dist;
				//no need to adjust for mates1 and A-rich: it is already taken care of by strand = '-'
				if(dist >= min_insert && dist <= max_insert ){
					map<long int, string>::iterator afind = chroms_names.find(chrom_id1);
					string chr_name = afind->second;
					if(strand1 == '+'){
						orig_start1 = pos1 - st1;
						orig_start2 = pos2 - en2;
					}
					else{
						orig_start1 = pos1 - en1;
						orig_start2 = pos2 - st2;
					}
					if(orig_start1 < 0)
						orig_start1 = pos1;
					if(orig_start2 < 0)
						orig_start2 = pos2;
					
					astat.mapped_pairs++;
					string out_read1 = aread1;
					string out_read2 = aread2;
					if(mates_pairs1.A_rich == true){
						read_rev_complement(out_read1, read_len1);
						read_rev_complement(out_read2, read_len2);
						strand1 = (strand1 == '+' ? strand1 = '-' : strand1 = '+');
						astat.mapped_first_Arich++;
					}
	
					out_pairs << read_id << "\t" << out_read1 << "\t" << out_read2 << "\t"
						<< chr_name << "\t" << strand1 <<"\t"
						<< pos1 << "\t" 
						<< pos2 << "\t"
						<< mates_pairs1.mism1 << "\t"
						<< mates_pairs2.mism1 << "\t"
						<< orig_start1 << "\t" << orig_start2 << endl;	
				}//correct insert
				else{
					astat.broken_wrong_insert++;
				}
			}//if correct strands
			else{
				astat.broken_inverse++;
			}
		}//if correct_chrom
		else{
			astat.broken_dif_chroms++;
		}
	}//if both mates are mapped uniquely
	else{
		if((mates_pairs1.mark_unique == 1 && mates_pairs2.mark_unique == 0) ||
			(mates_pairs1.mark_unique == 0 && mates_pairs2.mark_unique == 1)){
				astat.broken_mate_unmapped++;
		}
		else if((mates_pairs1.mark_unique == 1 && mates_pairs2.mark_unique > 1) ||
			(mates_pairs1.mark_unique > 1 && mates_pairs2.mark_unique == 1)){
			astat.broken_mate_amb++;
		}
		else if(mates_pairs1.mark_unique == 0 && mates_pairs2.mark_unique == 0){
			astat.broken_both_unmapped++;
		}
		else
			astat.ambiguous++;//both reads are amb

		print_singles(out_mates1, false, read_id, aread1, st1, en1, mates_pairs1, astat, read_len1);
		print_singles(out_mates1, true, read_id, aread2, st2, en2, mates_pairs2, astat, read_len2);
	}
	
}//print_pairs

void Anchor::print_singles(ofstream &out, bool second_mates, const _uli &read_id, 
	const string & aread1, const _uli &st1, const _uli &en1,  Mates &mates_pairs, Stat &astat, const _uli &read_len)
{

	long int orig_start1;
	if(mates_pairs.mark_unique == 1){
		long int chrom_id = 0;
		long int asize = size_chrom.size();
		//find the first start of chrom that is greater than pos
		long int pos1 = mates_pairs.pos1; 
		for(long int i = 0; i < asize; i++){
			if(pos1 >= starts_size_chrom[i])
				chrom_id++;
			else
				break;
		}//for i
		chrom_id--;
		pos1 = pos1 - starts_size_chrom[chrom_id];

		map<long int, string>::iterator afind = chroms_names.find(chrom_id);
		string chr_name = afind->second;
		if(mates_pairs.strand == '+')
			orig_start1 = pos1 - st1;
		else
			orig_start1 = pos1 - en1;
		if(orig_start1 < 0)
			orig_start1 = pos1;
		
		char strand = mates_pairs.strand;
		string out_read = aread1;
		if(mates_pairs.A_rich == true){
			read_rev_complement(out_read, read_len);
			strand = (strand == '+' ? strand = '-' : strand = '+');
		}
		out << read_id << "\t" << out_read << "\t" 
			<< chr_name << "\t" << strand <<"\t"
			<< pos1 << "\t" << mates_pairs.mism1 << "\t" << orig_start1 << endl;
	}//if
	/* Depricated
	else if(mates_pairs.mark_unique > 1){
		if(out_amb == true){
			if(second_mates == false)//this condition is only true when paired-end mapping for mates2
				out_amb1 << aread1 << endl;
			else
				out_amb2 << aread1 << endl;
		}
	}//ambiguous
	else{//unmapped
		if(unmapped == true){//output unmapped
			if(second_mates == false)//this condition is only true when paired-end mapping for mates2
				out_unmapped1 << aread1 << "\t" << st1 << "\t" << en1 << endl;
			else //this for single-end mapping is irrelevant
				out_unmapped2 << aread1 << "\t" << st1 << "\t" << en1 << endl;
		}
	}//unmapped
	*/
}//print_singles

void map_reads(Anchor &anc_ct, Anchor &anc_ga)
{
	//pair_reads_singles(unsigned long int read_id, string aread1, long int &contain_Ns, Stat &astat, short int len1, int t, int rs);
	_uli read_id = 0;
   Stat astat;
   string read, read2;
   _uli st1, en1, st2, en2;

	_uli read_len1, read_len2;
	if(anc_ct.is_pe == "1"){
		read_id = 0;

		ifstream in, in2;
		in.open(anc_ct.reads_file1.c_str(), ios::in);
		if(!in){
			cout << "can't open " << anc_ct.reads_file1 << " reads_file " << endl;
			anc_ct.space_release();
			exit(0);
		}
		in2.open(anc_ct.reads_file2.c_str(), ios::in);
		if(!in2){
			cout << "can't open " << anc_ct.reads_file2 << " reads_file2" << endl;
			anc_ct.space_release();
			exit(0);
		}	
		in >> read;
		in2 >> read2;
		if(read.length() > 0 && ((read[0] == '@') || (read[0] == '>')))
		{
			cout << "ERROR: brat-bw does not support FASTQ or FASTA format" << endl;
			anc_ct.space_release();
			exit(0);
		}
		while(!in.eof()){
			in >> st1 >> en1;
			in2 >> st2 >> en2;
			read_len1 = read.length();
			read_len2 = read2.length();

			pair_reads(read_id, read, astat, read_len1, st1, en1,
				read2, read_len2, st2, en2, anc_ct, anc_ga);

			read_id++;
			in >> read;
			in2 >> read2;		
		}//while

		cout << "Mapped uniquely pairs (pair count): " << astat.mapped_pairs << endl;
		cout << "Of them, with first mate being A-rich (from not original strands) (pair count): " << astat.mapped_first_Arich << endl;
		cout << "Broken pair: one mate is uniquely mapped, the other is unmapped (single-read count): " << astat.broken_mate_unmapped << endl;
		cout << "Broken pair: one mate is uniquely mapped, the other is ambiguos (single-read count): " << astat.broken_mate_amb << endl;
		cout << "Broken pair: mates mapped to different chromosomes (pair count): " << astat.broken_dif_chroms << endl;
		cout << "Broken pair: mates have wrong orientation (pair count): " << astat.broken_inverse << endl;
		cout << "Broken pair: mates have wrong inster size (pair count): " << astat.broken_wrong_insert << endl;
		cout << "Unmapped pair: both mates are unmapped (pair count): " << astat.unmapped << endl;
		cout << "Ambiguous pair: both mates are ambiguous (pair count): " << astat.ambiguous << endl;
		
	}//paired-end mapping
	else{
		bool A_rich = anc_ct.A_rich;
		bool opp_A_rich = (A_rich == true ? false : true);

		ifstream in;
		in.open(anc_ct.reads_file1.c_str(), ios::in);
		if(!in){
			cout << "can't open " << anc_ct.reads_file1 << " reads_file (option -s) " << endl;
			anc_ct.space_release();
			exit(0);
		}
			in >> read;
			if(read.length() > 0 && ((read[0] == '@') || (read[0] == '>')))
			{
				cout << "ERROR: brat-bw does not support FASTQ or FASTA format" << endl;
				anc_ct.space_release();
				exit(0);
			}
			read_id = 0;
			while(!in.eof()){
				in >> st1 >> en1;
				read_len1 = read.length();
				Mates mates_pairs;
				anc_ct.A_rich = A_rich;
				anc_ga.A_rich = A_rich;
				if(read_len1 >= anc_ct.MIN_READ && read_len1 <= anc_ct.SIZE){
					pair_reads_singles(read_id, read, astat, read_len1, st1, en1, mates_pairs, anc_ct, anc_ga);
				}
				else if(read_len1 > anc_ct.SIZE){
					pair_reads_singles_long(read_id, read, astat, read_len1, st1, en1, mates_pairs, anc_ct, anc_ga);
				}
				if((anc_ct.four_strands == true) && (mates_pairs.mark_unique < 2)){//if not ambiguous
					anc_ct.A_rich = opp_A_rich;
					anc_ga.A_rich = opp_A_rich;
					if(read_len1 >= anc_ct.MIN_READ && read_len1 <= anc_ct.SIZE){
						pair_reads_singles(read_id, read, astat, read_len1, st1, en1, mates_pairs, anc_ct, anc_ga);
					}
					else if(read_len1 > anc_ct.SIZE){
						pair_reads_singles_long(read_id, read, astat, read_len1, st1, en1, mates_pairs, anc_ct, anc_ga);
					}				
				}
				anc_ct.print_singles(anc_ct.out_pairs, false, read_id, read, st1, en1, mates_pairs, astat, read_len1);	

if(mates_pairs.mark_unique > 1)
	astat.ambiguous++;
else if(mates_pairs.mark_unique == 0)
	astat.unmapped++;
else
	astat.mapped_pairs++;
				read_id++;
				in >> read;
			}//while
			in.close(); in.clear();
cout << "Mapped uniquely: " << astat.mapped_pairs << endl;
cout << "Unmapped: " << astat.unmapped << endl;
cout << "Ambiguous: " << astat.ambiguous << endl;

	}//else singles

}//map_reads

int main(int argc, char* argv[])
{
	/**************************************
	This program calculates distribution of different fingerprints in the genome given
	*******************************************/
		/**************************************
		bitset [11000] is translated into a string as 00011 and into long int as 3
		so, least significant bits in the bitset are the leftmost
  *******************************************/
	
	if(argc < 6){//prefix, reads, output
		usage();
		return 0;
	}//if
	Anchor anc_ct(argc, argv, 1);//reads genome builds ta-, cg- binary representations once
	Anchor anc_ga(argc, argv, 2);
	
	map_reads(anc_ct, anc_ga);
	cout << "map_reads is done" << endl;
	return 0;
}//main


